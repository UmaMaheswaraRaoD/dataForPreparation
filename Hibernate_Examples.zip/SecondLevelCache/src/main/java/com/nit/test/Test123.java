package com.nit.test;

public class Test123 {
	public static void main(String[] args) {
		String s = "balakrishna";
		int count = 0;
		int num = 1;

		char[] charArray = s.toCharArray();
		for (char ocuurence : charArray) {
			if (ocuurence == 'a') {
				String.valueOf(num).charAt(0);

				count++;

			}
		}
	}
}
