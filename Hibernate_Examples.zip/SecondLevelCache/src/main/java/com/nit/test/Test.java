package com.nit.test;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Order;

import com.nit.util.HibernateUtils;

public class Test {

	public static void main(String[] args) {
		SessionFactory sf = HibernateUtils.getSf();
		Session hs1 = sf.openSession();

		String hql = "From Order";
		Query query1 = hs1.createQuery(hql);
		query1.setCacheable(true);
		List<Order> list1 = query1.getResultList();
		System.out.println("List1 size : " + list1.size());

		List<Order> list2 = query1.getResultList();
		System.out.println("List2size : " + list2.size());

		hs1.close();
		sf.close();
	}
}
