package com.services.test;

import com.services.dao.RobotDao;
import com.services.entities.Robot;

public class RobotDaoTest {
	public static void main(String[] args) {

		Robot r = new Robot();
		r.setName("Chitti-2.0");
		r.setType("Entertainement");

		RobotDao dao = new RobotDao();
		boolean isInserted = dao.insert(r);
		System.out.println("Record Inserted ?:"+isInserted);
	}
}
