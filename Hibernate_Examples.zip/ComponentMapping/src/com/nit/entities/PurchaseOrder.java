package com.nit.entities;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Entity;

@Entity
@Table(name = "PURCHASE_ORDER")
public class PurchaseOrder {

	@Id
	@GeneratedValue
	@Column(name = "O_ID")
	private Integer oid;

	@Column(name = "o_by")
	private String oby;

	@Column(name = "email")
	private String email;

	@Embedded
	private ShippingAddress addr;

	public Integer getOid() {
		return oid;
	}

	public void setOid(Integer oid) {
		this.oid = oid;
	}

	public String getOby() {
		return oby;
	}

	public void setOby(String oby) {
		this.oby = oby;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public ShippingAddress getAddr() {
		return addr;
	}

	public void setAddr(ShippingAddress addr) {
		this.addr = addr;
	}

	@Override
	public String toString() {
		return "PurchaseOrder [oid=" + oid + ", oby=" + oby + ", email="
				+ email + ", addr=" + addr + "]";
	}

}
