package com.nit.dao;

import java.io.Serializable;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.nit.entities.PurchaseOrder;
import com.nit.util.HibernateUtils;

public class PurchaseOrderDao {

	public void insert(PurchaseOrder po) {
		Session hs = HibernateUtils.getSession();
		Transaction tx = hs.beginTransaction();
		Serializable id = hs.save(po);
		System.out.println("Record inserted : " + id);
		tx.commit();
		hs.close();
	}
}
