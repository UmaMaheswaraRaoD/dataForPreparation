package com.nit.test;

import com.nit.dao.PurchaseOrderDao;
import com.nit.entities.PurchaseOrder;
import com.nit.entities.ShippingAddress;

public class PurchaseOrderDaoTest {

	public static void main(String[] args) {
		ShippingAddress saddr = new ShippingAddress();
		saddr.setCity("Hyd");
		saddr.setState("TG");
		saddr.setCountry("INDIA");

		PurchaseOrder po = new PurchaseOrder();
		po.setOby("Raju");
		po.setEmail("raj@in.com");

		po.setAddr(saddr);

		PurchaseOrderDao dao = new PurchaseOrderDao();
		dao.insert(po);

	}

}
