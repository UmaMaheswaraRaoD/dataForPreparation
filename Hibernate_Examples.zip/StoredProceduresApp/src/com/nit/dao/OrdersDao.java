package com.nit.dao;

import java.util.List;

import javax.persistence.ParameterMode;
import javax.persistence.Query;
import javax.persistence.SequenceGenerator;
import javax.persistence.StoredProcedureQuery;

import org.hibernate.Session;

import com.nit.util.HibernateUtils;

public class OrdersDao {

	public void findAll() {
		Session hs = HibernateUtils.getSession();
		StoredProcedureQuery sp = hs
				.createStoredProcedureQuery("GET_ALL_ORDERS");
		sp.registerStoredProcedureParameter(1, Class.class,
				ParameterMode.REF_CURSOR);
		sp.execute();
		List<Object[]> list = sp.getResultList();
		if (!list.isEmpty()) {
			for (Object[] arr : list) {
				System.out.println(arr[0] + "\t" + arr[1] + "\t" + arr[2]);
			}
		}
		hs.close();
	}

	public void findById(String orderId) {
		Session hs = HibernateUtils.getSession();

		hs.close();
	}

	public void findByEmail(String email, String name) {
		Session hs = HibernateUtils.getSession();

		hs.close();
	}

	public void findNameById(String orderId) {
		Session hs = HibernateUtils.getSession();
		StoredProcedureQuery sp = hs
				.createStoredProcedureQuery("GET_NAME_BY_ID");
		sp.registerStoredProcedureParameter(0, String.class, ParameterMode.IN);
		sp.registerStoredProcedureParameter(1, String.class, ParameterMode.OUT);
		sp.setParameter(0, orderId);
		sp.execute();
		String name = (String) sp.getOutputParameterValue(1);
		System.out.println("Name : " + name);
		hs.close();
	}

}
