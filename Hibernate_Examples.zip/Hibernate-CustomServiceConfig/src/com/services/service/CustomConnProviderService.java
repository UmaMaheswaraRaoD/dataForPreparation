package com.services.service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.hibernate.service.jdbc.connections.spi.ConnectionProvider;

public class CustomConnProviderService implements ConnectionProvider {

	@Override
	public boolean isUnwrappableAs(Class arg0) {
		return false;
	}
	
	@Override
	public <T> T unwrap(Class<T> arg0) {
		return null;
	}

	@Override
	public void closeConnection(Connection con) throws SQLException {
		if (con != null) con.close();
	}

	@Override
	public Connection getConnection() throws SQLException {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		Connection con = DriverManager.getConnection(
		"jdbc:oracle:thin:@locahost:1521/XE", "system", "admin");
		return con;
	}

	@Override
	public boolean supportsAggressiveRelease() {
		return false;
	}
}
