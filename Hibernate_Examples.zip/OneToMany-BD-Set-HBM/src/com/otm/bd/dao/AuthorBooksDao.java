package com.otm.bd.dao;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.otm.bd.entities.Author;
import com.otm.bd.entities.Book;
import com.otm.bd.util.HibernateUtil;

public class AuthorBooksDao {

	public boolean saveAuthorWithBooks() {
		boolean isInserted = false;
		Session hs = null;
		Transaction tx = null;
		try {
			hs = HibernateUtil.getSession();
			tx = hs.beginTransaction();

			Author a = new Author();
			a.setAuthorName("Gaven King");
			a.setAuthorEmail("gk@jboss.org");

			Book b1 = new Book();
			b1.setBookName("Hibernate");
			b1.setBookPrice(100.00);

			Book b2 = new Book();
			b2.setBookName("JPA");
			b2.setBookPrice(200.00);

			Set<Book> booksSet = new HashSet<Book>();
			booksSet.add(b1);
			booksSet.add(b2);

			a.setBooks(booksSet);

			Serializable ser = hs.save(a);

			if (ser != null) {
				isInserted = true;
			}
			tx.commit();
		} catch (Exception e) {
			e.printStackTrace();
			tx.rollback();
		} finally {
			if (hs != null)
				hs.close();
		}
		return isInserted;
	}

	public void findBookById(int bid) {
		Session hs = null;
		Transaction tx = null;
		try {
			hs = HibernateUtil.getSession();
			Book b = hs.get(Book.class, bid);
			Author a = b.getAuthor();
			System.out.println(a.getAuthorEmail());
		} catch (Exception e) {
			e.printStackTrace();
			tx.rollback();
		} finally {
			if (hs != null)
				hs.close();
		}
	}
}
