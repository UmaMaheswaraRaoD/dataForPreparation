package com.nit.dao;

import java.util.List;

import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;

import org.hibernate.SQLQuery;
import org.hibernate.Session;

import com.nit.entities.Orders;
import com.nit.util.HibernateUtils;

public class OrdersDao {

	public void findAll() {
		Session hs = HibernateUtils.getSession();
		Query query = hs.getNamedQuery("find_all_orders");
		List<Orders> list = query.getResultList();
		for (Orders o : list) {
			System.out.println(o);
		}
		CriteriaBuilder cb = hs.getCriteriaBuilder();
		CriteriaQuery cq = cb.createQuery();
		cq.getOrderList();
		hs.close();
	}

	public void findById(String orderId) {
		Session hs = HibernateUtils.getSession();
		Query query = hs.getNamedQuery("find_order_by_id");
		query.setParameter("oid", orderId);
		List<Orders> list = query.getResultList();
		for (Orders o : list) {
			System.out.println(o);
		}
		hs.close();
	}

	public void findTotal() {
		Session hs = HibernateUtils.getSession();
		/*
		 * SQLQuery query = hs.getNamedNativeQuery("find_total"); List<Long>
		 * list = query.getResultList(); if (!list.isEmpty()) {
		 * System.out.println("Total : " + list.get(0)); }
		 */
		hs.close();
	}

	public void findByEmail(String email, String name) {
		Session hs = HibernateUtils.getSession();
		String hql = "From Orders where orderBy=:name and orderPersonEmail=:email";
		Query query = hs.createQuery(hql);
		query.setParameter("email", email);
		query.setParameter("name", name);
		List<Orders> list = query.getResultList();
		for (Orders o : list) {
			System.out.println(o);
		}
		hs.close();
	}

	public void findNameById(String orderId) {
		Session hs = HibernateUtils.getSession();
		String hql = "select orderBy,orderPersonEmail from Orders where orderId=:id";
		Query query = hs.createQuery(hql);
		query.setParameter("id", orderId);
		List<Object[]> listArr = (List<Object[]>) query.getResultList();
		for (Object[] arr : listArr) {
			System.out.println(arr[0]);
			System.out.println(arr[1]);

		}
		hs.close();
	}

}
