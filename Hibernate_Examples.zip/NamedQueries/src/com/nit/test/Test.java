package com.nit.test;

import java.util.ArrayList;
import java.util.Iterator;

public class Test {

	public static void main(String[] args) {

		ArrayList<Integer> al = new ArrayList<Integer>();
		al.add(101);
		al.add(102);
		al.add(103);

		Iterator<Integer> itr = al.iterator();
		while (itr.hasNext()) {
			int i = itr.next();
			if (i == 101) {
				al.remove(0);
			}
		}
	}
}
