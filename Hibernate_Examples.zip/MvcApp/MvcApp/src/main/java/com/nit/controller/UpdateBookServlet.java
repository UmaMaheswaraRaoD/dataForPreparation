package com.nit.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.nit.model.BookModel;
import com.nit.service.BookService;
import com.nit.service.BookServiceImpl;

public class UpdateBookServlet extends HttpServlet {
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = null;
		RequestDispatcher rd = null;
		try {
			out = response.getWriter();
			// capture form data
			BookModel model = new BookModel();

			String id = request.getParameter("bookId");
			model.setBookId(Integer.parseInt(id));
			model.setBookName(request.getParameter("bookName"));
			model.setBookAuthor(request.getParameter("authorName"));
			String price = request.getParameter("price");
			if (price != null && !price.equals("")) {
				model.setPrice(Double.parseDouble(request.getParameter("price")));
			}
			model.setBookIsbn(request.getParameter("isbn"));

			// call service method to insert
			BookService service = new BookServiceImpl();
			boolean flag = service.update(model);

			if (flag) {
				request.setAttribute("succMsg", "Record updated");
			} else {
				request.setAttribute("errMsg", "Failed to update");
			}
			/*rd = request.getRequestDispatcher("RetriveBookServlet");
			rd.forward(request, response);*/
			response.sendRedirect("RetriveBookServlet");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
