package com.nit.dao;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.nit.entities.BookEntity;
import com.nit.util.HibernateUtils;

public class BookDaoImpl implements BookDao {

	public Serializable save(BookEntity entity) {
		SessionFactory sf = HibernateUtils.getSf();
		Session hs = sf.openSession();
		Transaction tx = hs.beginTransaction();
		entity.setIsActive("Y");
		Serializable id = hs.save(entity);

		tx.commit();
		hs.close();
		return id;
	}

	public List<BookEntity> findAll(int currPageNo, int pageSize) {
		SessionFactory sf = HibernateUtils.getSf();
		Session hs = sf.openSession();
		String hql = "From BookEntity where IsActive='Y'";
		Query query = hs.createQuery(hql);
		query.setFirstResult((currPageNo - 1) * pageSize);
		query.setMaxResults(pageSize);
		List<BookEntity> list = query.getResultList();
		hs.close();
		return list;
	}

	public BookEntity findById(Integer bookId) {
		SessionFactory sf = HibernateUtils.getSf();
		Session hs = sf.openSession();
		BookEntity entity = hs.get(BookEntity.class, bookId);
		hs.close();
		return entity;
	}

	public boolean update(BookEntity entity) {
		boolean isUpdated = false;
		try {
			SessionFactory sf = HibernateUtils.getSf();
			Session hs = sf.openSession();
			Transaction tx = hs.beginTransaction();
			entity.setIsActive("Y");
			hs.update(entity);
			isUpdated = true;
			tx.commit();
			hs.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return isUpdated;
	}

	public boolean delete(Integer bookId) {
		boolean isDeleted = false;
		String hql = "update BookEntity set IsActive='N' where bookId=:id";
		Session hs = HibernateUtils.getSf().openSession();
		Transaction tx = hs.beginTransaction();
		Query query = hs.createQuery(hql);
		query.setParameter("id", bookId);
		int no = query.executeUpdate();
		if (no > 0) {
			isDeleted = true;
		}
		tx.commit();
		hs.close();
		return isDeleted;
	}

	public long totalRecords() {
		String hql = "select count(*) from BookEntity";
		Session hs = HibernateUtils.getSf().openSession();
		Query query = hs.createQuery(hql);
		List<Long> longList = query.getResultList();
		return longList.get(0);
	}

}
