package com.nit.service;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.nit.dao.BookDao;
import com.nit.dao.BookDaoImpl;
import com.nit.entities.BookEntity;
import com.nit.model.BookModel;

public class BookServiceImpl implements BookService {

	BookDao bookDao = new BookDaoImpl();

	public Serializable insert(BookModel model) {
		BookEntity entity = new BookEntity();
		entity.setBookIsbn(model.getBookIsbn());
		entity.setBookName(model.getBookName());
		entity.setAuthorName(model.getBookAuthor());
		entity.setBookPrice(model.getPrice());
		return bookDao.save(entity);

	}

	public List<BookModel> retriveAll(int currPageNo, int pageSize) {
		List<BookEntity> entities = bookDao.findAll(currPageNo, pageSize);
		List<BookModel> modelsList = new ArrayList<BookModel>();
		for (BookEntity entity : entities) {
			BookModel model = new BookModel();
			model.setBookAuthor(entity.getAuthorName());
			model.setBookId(entity.getBookId());
			model.setBookIsbn(entity.getBookIsbn());
			model.setPrice(entity.getBookPrice());
			model.setBookName(entity.getBookName());
			modelsList.add(model);
		}

		return modelsList;
	}

	public BookModel retriveById(Integer bookId) {
		BookEntity entity = bookDao.findById(bookId);
		BookModel model = new BookModel();
		model.setBookAuthor(entity.getAuthorName());
		model.setBookId(entity.getBookId());
		model.setBookIsbn(entity.getBookIsbn());
		model.setPrice(entity.getBookPrice());
		model.setBookName(entity.getBookName());
		return model;
	}

	public boolean update(BookModel model) {
		BookEntity entity = new BookEntity();
		entity.setBookIsbn(model.getBookIsbn());
		entity.setBookName(model.getBookName());
		entity.setAuthorName(model.getBookAuthor());
		entity.setBookPrice(model.getPrice());
		entity.setBookId(model.getBookId());
		return bookDao.update(entity);
	}

	public boolean delete(Integer bookId) {
		return bookDao.delete(bookId);
	}

	public long totalRecords() {
		return bookDao.totalRecords();
	}

}
