package com.nit.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.Serializable;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.nit.model.BookModel;
import com.nit.service.BookService;
import com.nit.service.BookServiceImpl;

public class StoreBookServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = null;
		RequestDispatcher rd = null;
		try {
			out = response.getWriter();
			// capture form data
			BookModel model = new BookModel();
			model.setBookName(request.getParameter("bookName"));
			model.setBookAuthor(request.getParameter("authorName"));

			String price = request.getParameter("price");
			if (price != null && !price.equals("")) {
				model.setPrice(Double.parseDouble(request.getParameter("price")));
			}
			model.setBookIsbn(request.getParameter("isbn"));

			// call service method to insert
			BookService service = new BookServiceImpl();
			Serializable id = service.insert(model);

			if (id != null) {
				request.setAttribute("succMsg", "Record inserted with Id : "
						+ id);
				rd = request.getRequestDispatcher("index.jsp");
				rd.forward(request, response);
			} else {
				request.setAttribute("errMsg", "Failed to insert");
				rd = request.getRequestDispatcher("index.jsp");
				rd.forward(request, response);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}
