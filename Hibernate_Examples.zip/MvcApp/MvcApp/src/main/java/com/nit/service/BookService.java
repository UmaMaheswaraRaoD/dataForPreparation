package com.nit.service;

import java.io.Serializable;
import java.util.List;

import com.nit.model.BookModel;

public interface BookService {

	public Serializable insert(BookModel model);

	public List<BookModel> retriveAll(int currPageNo,int pageSize);

	public BookModel retriveById(Integer bookId);

	public boolean update(BookModel model);

	public boolean delete(Integer bookId);
	
	public long totalRecords();

}
