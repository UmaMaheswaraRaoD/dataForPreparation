package com.nit.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.nit.model.BookModel;
import com.nit.service.BookService;
import com.nit.service.BookServiceImpl;

public class EditBookServlet extends HttpServlet {
	
	BookService service = new BookServiceImpl();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String id = request.getParameter("bookId");
		if(id!=null && !id.equals("")){
			int bookId = Integer.parseInt(id);
			BookModel model=service.retriveById(bookId);
			request.setAttribute("model", model);
			request.getRequestDispatcher("editBook.jsp").forward(request, response);
		}
	
	}

}
