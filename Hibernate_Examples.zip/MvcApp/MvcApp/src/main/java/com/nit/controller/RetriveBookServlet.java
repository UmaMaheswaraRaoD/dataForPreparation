package com.nit.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.nit.model.BookModel;
import com.nit.service.BookService;
import com.nit.service.BookServiceImpl;

public class RetriveBookServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	BookService service = new BookServiceImpl();

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		int currPageNo = 1;
		int pageSize = 3;
		long totRecords = service.totalRecords();
		long totalPages = (totRecords / pageSize)
				+ (totRecords % pageSize > 0 ? 1 : 0);
		request.setAttribute("pages", totalPages);
		request.setAttribute("cPageNo", currPageNo);

		String pageNo = request.getParameter("currPageNo");
		if (pageNo != null && !pageNo.equals("")) {
			currPageNo = Integer.parseInt(pageNo);
		}
		request.setAttribute("cPageNo", currPageNo);

		List<BookModel> modelsList = service.retriveAll(currPageNo, pageSize);
		request.setAttribute("models", modelsList);

		RequestDispatcher rd = request.getRequestDispatcher("viewBooks.jsp");
		rd.forward(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
	}

}
