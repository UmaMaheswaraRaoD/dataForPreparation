package com.nit.dao;

import com.nit.entities.BookEntity;

import java.io.Serializable;
import java.util.List;

public interface BookDao {

	public Serializable save(BookEntity entity);

	public List<BookEntity> findAll(int currPageNo, int pageSize);

	public BookEntity findById(Integer bookId);

	public boolean update(BookEntity entity);

	public boolean delete(Integer bookId);
	
	public long totalRecords();

}
