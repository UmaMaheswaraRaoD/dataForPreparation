package com.mto.test;

import com.mto.dao.CountryStateDao;

public class MTOTestApp {

	public static void main(String[] args) {

		CountryStateDao dao = new CountryStateDao();
		// dao.saveStatesWithCountry();
		// dao.findStateById(2);
		// dao.addStateToExistingCountry();
		// dao.deleteOneStateFromCountry();
		dao.deleteAllStates();
	}
}
