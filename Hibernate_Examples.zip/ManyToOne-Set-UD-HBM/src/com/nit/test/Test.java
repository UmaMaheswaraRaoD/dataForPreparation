package com.nit.test;

import com.nit.dao.CountryStateDao;

public class Test {

	public static void main(String[] args) {
		CountryStateDao dao = new CountryStateDao();
		//dao.saveStatesWithCountry();
		dao.findStateById();

	}
}
