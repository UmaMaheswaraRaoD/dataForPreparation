package com.nit.dao;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.nit.entities.Country;
import com.nit.entities.State;
import com.nit.util.HibernateUtils;

public class CountryStateDao {

	public void saveStatesWithCountry() {

		Country c = new Country();
		c.setCountryId(101);
		c.setCountryName("India");
		c.setCountryCode("+91");

		State s1 = new State();
		s1.setStateId(201);
		s1.setStateName("Andhra Pradesh");
		s1.setCountry(c);

		State s2 = new State();
		s2.setStateId(202);
		s2.setStateName("Telangana");
		s2.setCountry(c);

		Session hs = HibernateUtils.getSession();
		Transaction tx = hs.beginTransaction();

		hs.save(s1);
		hs.save(s2);

		tx.commit();
		hs.close();
	}

	public void findStateById() {
		Session hs = HibernateUtils.getSession();
		State s = (State) hs.get(State.class, 201);
		hs.close();
	}

}
