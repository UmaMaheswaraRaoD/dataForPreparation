package com.nit.apps.main;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

public class TestCalculator {
	static Calculator calc;

	@BeforeClass
	public static void setUp() {
		System.out.println("in setup method");
		calc = new Calculator();
	}

	@Test
	public void addTest() {
		System.out.println("in add method");
		int a = calc.add(10, 20);
		int e = 40;
		assertEquals(e, a);
	}

	@Test
	public void mulTest() {
		System.out.println("mul...");
		int actual = calc.mul(5, 5);
		int expected = 25;
		assertEquals(expected, actual);
	}

	@AfterClass
	public static void tearDown() {
		System.out.println("tear down method");
		calc = null;
	}

}
