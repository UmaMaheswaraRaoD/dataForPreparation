package com.nit.apps.main;

import static org.junit.Assert.*;

import java.sql.Connection;

import org.junit.BeforeClass;
import org.junit.Test;

public class SingleConProviderTest {

	static SingleConnecionProvider provider = null;

	@BeforeClass
	public static void setUp() {
		provider = new SingleConnecionProvider();
	}

	@Test
	public void testGetConn() {
		Connection con1 = provider.getConnection();
		Connection con2 = provider.getConnection();
		assertSame(con1, con2);
	}

}
