package com.nit.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "PRODUCT_DETAILS")
public class ProductEntity {

	@Id
	@GeneratedValue
	@Column(name = "P_ID")
	private Integer pid;

	@Column(name = "P_NAME")
	private String pname;

	@Column(name = "P_PRICE")
	private Double price;

	public Integer getPid() {
		return pid;
	}

	public void setPid(Integer pid) {
		this.pid = pid;
	}

	public String getPname() {
		return pname;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "ProductModel [pid=" + pid + ", pname=" + pname + ", price="
				+ price + "]";
	}

}
