package com.nit.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "ORDER_DETAILS")
public class Orders {

	@Id
	@Column(name = "ORDER_ID")
	@GenericGenerator(name = "custom_gen", strategy = "com.nit.util.OrderIdGenerator")
	@GeneratedValue(generator = "custom_gen")
	private String orderId;

	@Column(name = "ORDER_BY")
	private String orderBy;

	@Column(name = "ORDR_PRSN_EMAIL")
	private String orderPersonEmail;

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getOrderBy() {
		return orderBy;
	}

	public void setOrderBy(String orderBy) {
		this.orderBy = orderBy;
	}

	public String getOrderPersonEmail() {
		return orderPersonEmail;
	}

	public void setOrderPersonEmail(String orderPersonEmail) {
		this.orderPersonEmail = orderPersonEmail;
	}

	@Override
	public String toString() {
		return "Orders [orderId=" + orderId + ", orderBy=" + orderBy
				+ ", orderPersonEmail=" + orderPersonEmail + "]";
	}

}
