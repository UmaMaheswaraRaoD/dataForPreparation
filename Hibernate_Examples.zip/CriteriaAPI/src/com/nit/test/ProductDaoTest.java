package com.nit.test;

import java.util.List;

import com.nit.dao.ProductDao;
import com.nit.entities.ProductEntity;

public class ProductDaoTest {

	public static void main(String[] args) {

		ProductDao dao = new ProductDao();
		List<ProductEntity> pList = null;
		// pList = dao.findByPrice(2000.00);
		// pList = dao.findByPriceNotNull();
		// pList = dao.findByPriceInBtwn(2000.00, 5000.00);
		// pList = dao.findUsingOr();

		/*
		 * List<Integer> pids = new ArrayList<Integer>(); pids.add(1);
		 * pids.add(2); pids.add(3); pids.add(4);
		 * 
		 * pList = dao.findByIds(pids);
		 * 
		 * System.out.println("=====Size ====: " + pList.size()); if
		 * (!pList.isEmpty()) { for (ProductEntity entity : pList) {
		 * System.out.println(entity); } } else {
		 * System.out.println("No Products Found"); }
		 */

		// dao.findNameAndPriceById(2);

		// dao.findMaxPrice();
		dao.findTotalRecords();

		pList = dao.findByPartialName("Disk");
		for (ProductEntity entity : pList) {
			System.out.println(entity);
		}
	}
}
