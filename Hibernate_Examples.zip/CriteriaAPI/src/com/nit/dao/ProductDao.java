package com.nit.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import com.nit.entities.ProductEntity;
import com.nit.util.HibernateUtils;

public class ProductDao {

	public List<ProductEntity> findByPrice(double price) {
		List<ProductEntity> pList = null;
		Session hs = null;
		try {
			hs = HibernateUtils.getSession();
			Criteria c = hs.createCriteria(ProductEntity.class);
			c.add(Restrictions.gt("price", price));
			c.addOrder(Order.desc("price"));
			pList = c.list();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return pList;
	}

	public List<ProductEntity> findByPriceNotNull() {
		List<ProductEntity> pList = null;
		try {
			Session hs = HibernateUtils.getSession();
			Criteria c = hs.createCriteria(ProductEntity.class);
			c.add(Restrictions.isNotNull("price"));
			c.add(Restrictions.gt("price", 5000.00));
			pList = c.list();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return pList;
	}

	public List<ProductEntity> findByPriceInBtwn(double startPrice,
			double endPrice) {
		List<ProductEntity> pList = null;
		try {
			Session hs = HibernateUtils.getSession();
			Criteria c = hs.createCriteria(ProductEntity.class);
			c.add(Restrictions.between("price", startPrice, endPrice));
			pList = c.list();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return pList;
	}

	public List<ProductEntity> findUsingOr() {
		List<ProductEntity> pList = null;
		try {
			Session hs = HibernateUtils.getSession();
			Criteria c = hs.createCriteria(ProductEntity.class);
			Criterion c1 = Restrictions.lt("price", 2000.00);
			Criterion c2 = Restrictions.isNull("price");
			c.add(Restrictions.or(c1, c2));
			pList = c.list();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return pList;
	}

	public List<ProductEntity> findByIds(List<Integer> pids) {
		List<ProductEntity> pList = null;
		try {
			Session hs = HibernateUtils.getSession();
			Criteria c = hs.createCriteria(ProductEntity.class);
			c.add(Restrictions.in("pid", pids));
			pList = c.list();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return pList;
	}

	public void findNameAndPriceById(int pid) {
		try {
			Session hs = HibernateUtils.getSession();
			Criteria c = hs.createCriteria(ProductEntity.class);
			c.add(Restrictions.eq("pid", pid));
			ProjectionList pList = Projections.projectionList();
			pList.add(Projections.property("pname"));
			pList.add(Projections.property("price"));
			c.setProjection(pList);
			List<Object[]> objArr = c.list();

			for (Object[] arr : objArr) {
				System.out.println(arr[0] + "--" + arr[1]);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void findMaxPrice() {
		try {
			Session hs = HibernateUtils.getSession();
			Criteria c = hs.createCriteria(ProductEntity.class);
			c.setProjection(Projections.max("price"));
			List<Double> list = c.list();

			if (!list.isEmpty()) {
				System.out.println("Max Price : " + list.get(0));
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void findTotalRecords() {
		try {
			Session hs = HibernateUtils.getSession();
			Criteria c = hs.createCriteria(ProductEntity.class);
			c.setProjection(Projections.count("pid"));
			List<Integer> list = c.list();
			if (!list.isEmpty()) {
				System.out.println("Total Records : " + list.get(0));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public List<ProductEntity> findByPartialName(String name) {
		List<ProductEntity> pList = null;
		try {
			Session hs = HibernateUtils.getSession();
			Criteria c = hs.createCriteria(ProductEntity.class);
			c.add(Restrictions.ilike("pname", name, MatchMode.START));
			pList = c.list();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return pList;
	}
}
