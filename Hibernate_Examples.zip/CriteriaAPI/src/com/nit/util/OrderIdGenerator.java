package com.nit.util;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.hibernate.HibernateException;
import org.hibernate.engine.spi.SharedSessionContractImplementor;
import org.hibernate.id.IdentifierGenerator;

public class OrderIdGenerator implements IdentifierGenerator {
	@Override
	public Serializable generate(SharedSessionContractImplementor session,
			Object obj) throws HibernateException {
		String prefix = "OD";
		Connection con = session.connection();
		String sql = "select oid_seq.nextval from dual";
		PreparedStatement pstmt;
		String pkVal = null;
		int suffix = 0;
		try {
			pstmt = con.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				suffix = rs.getInt(1);
			}
			pkVal = prefix.concat(String.valueOf(suffix));
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return pkVal;
	}
}
