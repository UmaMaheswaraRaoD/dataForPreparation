package com.nit.service;

public interface LoginService {
		
	public boolean login(String uname,String pwd);
}
