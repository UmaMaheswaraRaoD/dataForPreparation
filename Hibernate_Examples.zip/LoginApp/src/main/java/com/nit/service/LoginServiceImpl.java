package com.nit.service;

import com.nit.dao.LoginDao;
import com.nit.dao.LoginDaoImpl;
import com.nit.model.UserModel;

public class LoginServiceImpl implements LoginService {

	private LoginDao dao;

	public boolean login(String uname, String pwd) {
		dao = new LoginDaoImpl();
		UserModel model = dao.loadUserRecord(uname, pwd);
		return model != null ? true : false;
	}
}
