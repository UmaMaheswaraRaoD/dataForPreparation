package com.nit.dao;

import com.nit.model.UserModel;

public interface LoginDao {

	public UserModel loadUserRecord(String uname, String pwd);

}
