package com.nit.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.junit.runner.Result;

import com.nit.model.UserModel;

public class LoginDaoImpl implements LoginDao {
	private static final String DB_URL = "jdbc:oracle:thin:@localhost:1521/XE";
	private static final String DB_UNAME = "system";
	private static final String DB_PWD = "admin";
	private static final String DB_DRIVER_CLS = "oracle.jdbc.driver.OracleDriver";

	public UserModel loadUserRecord(String uname, String pwd) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		UserModel model = null;
		try {
			Class.forName(DB_DRIVER_CLS);
			con = DriverManager.getConnection(DB_URL, DB_UNAME, DB_PWD);
			String sql = "SELECT * FROM USER_MASTER WHERE USER_NAME=? AND USER_PWD=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, uname);
			pstmt.setString(2, pwd);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				model = new UserModel();
				model.setUname(rs.getString("USER_NAME"));
				model.setPwd(rs.getString("USER_PWD"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return model;
	}
}
