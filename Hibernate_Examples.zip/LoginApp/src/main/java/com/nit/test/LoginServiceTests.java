package com.nit.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.nit.service.LoginService;
import com.nit.service.LoginServiceImpl;

public class LoginServiceTests {

	@Test
	public void loginTest() {
		LoginService service = new LoginServiceImpl();
		boolean actual = service.login("7hhkkhk","abc@123");
		assertEquals(true, actual);
	}

}
