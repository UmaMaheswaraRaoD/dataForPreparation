package com.nit.test;

import java.util.List;

import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;

public class TestRunner {

	public static void main(String[] args) {
		Result result = JUnitCore.runClasses(LoginServiceTests.class);
		System.out.println("total : " + result.getRunCount());
		System.out.println("failed:" + result.getFailureCount());

		List<Failure> failures = result.getFailures();
		for (Failure f : failures) {
			System.out.println(f.getMessage());
		}
	}

}
