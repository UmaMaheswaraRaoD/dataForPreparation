package com.nit.apps.util;

public class AppConstants {

	public static final Integer PAGE_SIZE = 2;
	public static String sucessMsg = "Emp Record creatd with Emp ID : ";
	public static String errMsg = "Failed create Emp ID.. please check DB Details";
	

}
