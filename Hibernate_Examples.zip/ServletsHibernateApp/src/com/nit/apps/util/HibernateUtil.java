package com.nit.apps.util;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HibernateUtil {

	private static SessionFactory sf = null;;

	private HibernateUtil() {
	}

	public static SessionFactory getSessionFactory() {

		if (sf == null) {
			Configuration cfg = new Configuration();
			cfg.configure();
			synchronized (cfg) {
				if (sf == null) {
					sf = cfg.buildSessionFactory();
				}
			}
		}
		return sf;
	}

}
