package com.nit.apps.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.nit.apps.dao.EmpDao;
import com.nit.apps.dao.EmpDaoImpl;
import com.nit.apps.model.Employee;
import com.nit.apps.util.AppConstants;

public class InsertEmpServlet extends HttpServlet {

	/**
	 * 
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		try {
			// capture form data
			String ename = request.getParameter("ename");
			String email = request.getParameter("email");
			String esal = request.getParameter("esal");

			Employee emp = new Employee();
			
			//setting form data to employee object
			emp.setEname(ename);
			emp.setEmail(email);
			if (esal != null) {
				emp.setSalary(Double.parseDouble(esal));
			}

			// store into database
			EmpDao dao = new EmpDaoImpl();
			Integer generatedEid = dao.registerEmp(emp);

			// display success msg to user
			request.setAttribute("succMsg", AppConstants.sucessMsg+generatedEid);
			
		} catch (Exception e) {
			e.printStackTrace();
			// display error msg to user
			request.setAttribute("errMsg", AppConstants.errMsg);
		}

		// redirecting the user to same page with success/error msg
		RequestDispatcher rd = request.getRequestDispatcher("index.jsp");
		rd.forward(request, response);

	}

}
