package com.nit.apps.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.nit.apps.dao.EmpDao;
import com.nit.apps.dao.EmpDaoImpl;
import com.nit.apps.model.Employee;
import com.nit.apps.util.AppConstants;

/**
 * Servlet implementation class ViewEmpDataServlet
 */
public class ViewEmpDataServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static Integer PAGE_SIZE = 0;
	private static Integer pageNumber = 1;
	private static Integer totalPages = 1;

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		EmpDao dao = new EmpDaoImpl();

		String str = request.getParameter("pageNumber");
		if (str != null) {
			pageNumber = Integer.parseInt(str);
		}

		Integer totalRecords = dao.getTotalEmpRecordsCount();

		PAGE_SIZE = AppConstants.PAGE_SIZE;

		totalPages = totalRecords / PAGE_SIZE
				+ (totalRecords % PAGE_SIZE > 0 ? 1 : 0);
		System.out.println("total pages :" + totalPages);

		request.setAttribute("totalPages", totalPages);

		List<Employee> empList = dao.getAllEmpRecords(pageNumber, PAGE_SIZE);

		request.setAttribute("empList", empList);
		request.setAttribute("pageNumber", pageNumber);

		RequestDispatcher rd = request.getRequestDispatcher("empData.jsp");
		rd.forward(request, response);

	}

}
