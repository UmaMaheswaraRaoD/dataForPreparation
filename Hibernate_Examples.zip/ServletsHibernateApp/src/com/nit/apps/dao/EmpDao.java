package com.nit.apps.dao;

import java.util.List;

import com.nit.apps.model.Employee;

public interface EmpDao {

	public Integer registerEmp(Employee emp);

	public List<Employee> getAllEmpRecords(int pageNumber,int pageSize);
	
	public Integer getTotalEmpRecordsCount();

}
