package com.nit.test;

import com.nit.dao.ProductDao;

public class ProductDaoTest {

	public static void main(String[] args) {
		
		ProductDao dao = new ProductDao();
		dao.findAll();

	}
}
