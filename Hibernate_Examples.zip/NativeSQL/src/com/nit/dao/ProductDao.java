package com.nit.dao;

import java.util.List;

import org.hibernate.SQLQuery;
import org.hibernate.Session;

import com.nit.entities.ProductEntity;
import com.nit.util.HibernateUtils;

public class ProductDao {

	public void findAll() {
		try {
			Session hs = HibernateUtils.getSession();
			String sql = "SELECT p_id,p_name FROM PRODUCT_DETAILS";
			SQLQuery query = hs.createSQLQuery(sql).addEntity(
					ProductEntity.class);
			List<ProductEntity> list = query.list();
			for (ProductEntity entity : list) {
				System.out.println(entity);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
