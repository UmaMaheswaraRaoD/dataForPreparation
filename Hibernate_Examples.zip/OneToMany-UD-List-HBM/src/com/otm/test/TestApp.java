package com.otm.test;

import com.otm.dao.AuthorBooksDao;
import com.otm.util.HibernateUtil;

public class TestApp {

	public static void main(String[] args) {
		AuthorBooksDao dao = new AuthorBooksDao();
		dao.saveAuthorWithBooks();
		// dao.findAuthorWithBooks(1);

		// dao.deleteBookById(1, 2);

		//dao.deleteAllChilds(1);

		// closing session factory
		HibernateUtil.closeSf();
	}
}
