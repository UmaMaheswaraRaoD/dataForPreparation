package com.nit.dao;

import java.util.HashMap;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.nit.entities.Author;
import com.nit.entities.Book;
import com.nit.util.HibernateUtils;

public class AuthorBookDao {

	public void saveAuthorWithBooks() {
		// Creating parent object
		Author a = new Author();
		a.setAid(102);
		a.setAuthorName("Rod Johnson");
		a.setEmail("rd@sun.com");

		// create child1 object
		Book b1 = new Book();
		b1.setBookId(203);
		b1.setBookName("Spring");
		b1.setIsbn("ISBN003");
		b1.setPrice(300.00);

		// create child2 object
		Book b2 = new Book();
		b2.setBookId(204);
		b2.setBookName("Spring Boot");
		b2.setIsbn("ISBN004");
		b2.setPrice(400.00);

		// Storing books objs to collection
		Map<String, Book> books = new HashMap();
		books.put("book-1", b1);
		books.put("book-2", b2);
		
		// Add child objects to Parent
		a.setBooks(books);

		Session hs = HibernateUtils.getSession();
		Transaction tx = hs.beginTransaction();
		// Storing parent object
		hs.save(a);
		System.out.println("Record inserted");
		tx.commit();
		hs.close();
	}

}
