package com.otm.test;

import com.otm.dao.AuthorBookDao;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AuthorBookDao dao = new AuthorBookDao();
		dao.saveAuthorWithBook();
	}

}
