package com.otm.dao;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.otm.entiteis.Author;
import com.otm.entiteis.Book;
import com.otm.util.HibernateUtil;

public class AuthorBookDao {
	public void saveAuthorWithBook() {

		Author a = new Author();
		a.setName("cathie");
		a.setEmail("cathie@gmail.com");

		Book b1 = new Book();
		b1.setName("JSE");
		b1.setPrice(100.00);
		b1.setIsbn("79785332");

		Book b2 = new Book();
		b2.setName("JEE");
		b2.setPrice(150.00);
		b2.setIsbn("55322799");

		Set<Book> booksSet = new HashSet();
		booksSet.add(b1);
		booksSet.add(b2);

		a.setBooks(booksSet);
		Session hs = HibernateUtil.getSession();
		Transaction tx = hs.beginTransaction();
		hs.save(a);
		tx.commit();
		hs.close();
	}

}
