package com.mtm.dao;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.mtm.entities.Project;
import com.mtm.entities.Resource;
import com.mtm.util.HibernateUtil;

public class ProjecetResourcesDao {
	public boolean saveResourceWithProjects() {
		boolean isInserted = false;
		Session hs = null;
		Transaction tx = null;
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MMM/yyyy");
		try {
			hs = HibernateUtil.getSession();
			tx = hs.beginTransaction();

			Resource r1 = new Resource();
			r1.setResourceName("Smith");
			r1.setResourceEmail("smit@in.com");

			Resource r2 = new Resource();
			r2.setResourceName("Dean");
			r2.setResourceEmail("de@in.com");

			Project p1 = new Project();
			p1.setProjName("IRCTC");
			p1.setStartDt(new Date());
			p1.setEndDt(sdf.parse("27/Jan/2019"));

			Project p2 = new Project();
			p2.setProjName("Gmail");
			p2.setStartDt(new Date());
			p2.setEndDt(sdf.parse("27/Jun/2019"));

			Set<Resource> resSet = new HashSet<Resource>();
			resSet.add(r1);
			resSet.add(r2);

			Set<Project> projSet = new HashSet<Project>();
			projSet.add(p1);
			projSet.add(p2);

			// Associate parent with child
			r1.setProjects(projSet);
			r2.setProjects(projSet);

			// Saving
			hs.save(r1);
			hs.save(r2);

			tx.commit();
			hs.close();
			isInserted = true;
		} catch (Exception e) {
			e.printStackTrace();
			tx.rollback();
		}

		return isInserted;

	}

	public void findResourceByProjId(int pid) {
		Session hs = null;
		try {
			hs = HibernateUtil.getSession();
			Project p = hs.get(Project.class, pid);
			Set<Resource> resSet = p.getResources();
			if (!resSet.isEmpty()) {
				for (Resource r : resSet) {
					System.out.println(r.getResourceName());
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void findProjectByResId(int rid) {
		Session hs = null;
		try {
			hs = HibernateUtil.getSession();
			Resource r = hs.get(Resource.class, rid);
			Set<Project> projects = r.getProjects();
			if (!projects.isEmpty()) {
				for (Project p : projects) {
					System.out.println(p.getProjName());
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void deleteResourceFromProjet(int rid,int pid) {
		Session hs = null;
		Transaction tx = null;
		try {
			hs = HibernateUtil.getSession();
			tx = hs.beginTransaction();
			Resource r = hs.get(Resource.class, rid);
			Set<Project> projects = r.getProjects();
			Project p = hs.get(Project.class, pid);
			projects.remove(p);
			tx.commit();
			hs.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}


}
