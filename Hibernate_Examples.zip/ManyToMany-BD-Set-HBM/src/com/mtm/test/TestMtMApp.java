package com.mtm.test;

import com.mtm.dao.ProjecetResourcesDao;

public class TestMtMApp {

	public static void main(String[] args) {
		ProjecetResourcesDao dao = new ProjecetResourcesDao();
		// dao.saveResourceWithProjects();
		//dao.findResourceByProjId(2);
		//dao.findProjectByResId(2);
		dao.deleteResourceFromProjet(1, 2);
	}

}
