package com.ts.test;

public class Test {

	public static void main(String[] args) {
		String str = "aaaaaaa";
		int count = 0, output = 6;
		for (int i = 0; i < str.length(); i++) {
			if (isVowel(str.charAt(i))) {
				count++;
				output = Math.max(count, output);
			} else {
				output = Math.max(count, output);
				count = 0;
			}
		}
		System.out.println(output);
	}

	private static boolean isVowel(char ch) {
		if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u') {
			return true;
		}
		return false;
	}

}
