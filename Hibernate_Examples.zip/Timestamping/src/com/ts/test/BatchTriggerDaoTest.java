package com.ts.test;

import com.ts.dao.BatchTriggerDao;
import com.ts.entities.BatchTrigger;

public class BatchTriggerDaoTest {

	public static void main(String[] args) {
		BatchTrigger bt = new BatchTrigger();
		bt.setCreateUserId("ieapp");
		bt.setTriggeredBy("Batch");
		bt.setTriggerName("Notice Trigger");
		
		BatchTriggerDao dao  = new BatchTriggerDao();
		dao.insert(bt);

	}

}
