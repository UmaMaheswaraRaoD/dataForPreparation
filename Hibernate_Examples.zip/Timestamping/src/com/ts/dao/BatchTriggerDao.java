package com.ts.dao;

import org.hibernate.Transaction;
import org.hibernate.Session;

import com.ts.entities.BatchTrigger;
import com.ts.util.HibernateUtils;

public class BatchTriggerDao {

	public void insert(BatchTrigger trigger) {
		Session hs = HibernateUtils.getSession();
		Transaction tx = hs.beginTransaction();
		hs.save(trigger);
		System.out.println("Trigger inserted...");
		tx.commit();
		hs.close();
	}

}
