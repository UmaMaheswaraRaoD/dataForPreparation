package com.nit.dao;

import java.io.Serializable;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.nit.entities.CurrentAccount;
import com.nit.entities.SavingsAccount;
import com.nit.util.HibernateUtils;

public class AccountDao {

	public void insert(SavingsAccount sa) {
		Session hs = HibernateUtils.getSession();
		Transaction tx = hs.beginTransaction();
		Serializable id = hs.save(sa);
		System.out.println("Record inserted : " + id);
		tx.commit();
		hs.close();
	}

	public void insert(CurrentAccount ca) {
		Session hs = HibernateUtils.getSession();
		Transaction tx = hs.beginTransaction();
		Serializable id = hs.save(ca);
		System.out.println("Record inserted : " + id);
		tx.commit();
		hs.close();
	}

}
