package com.nit.test;

import com.nit.dao.AccountDao;
import com.nit.entities.CurrentAccount;
import com.nit.entities.SavingsAccount;

public class AccountDaoTest {
	
	public static void main(String[] args) {
		
		AccountDao dao = new AccountDao();
		
		/*SavingsAccount sa = new SavingsAccount();
		sa.setBankName("Axis");
		sa.setBranchName("S.R.Nagar");
		sa.setHolderName("John");
		sa.setMinBal(500.00);
		
		dao.insert(sa);*/
		CurrentAccount ca = new CurrentAccount();
		ca.setBankName("ICICI");
		ca.setBranchName("S.R.Nagar");
		ca.setHolderName("Suman");
		ca.setTxLimit(40000.00);
		dao.insert(ca);
		
		
	}

}
