package com.nit.apps.otm;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class OneToManyTest {

	public static void main(String[] args) throws Exception {
		// insert();
		 retrieve();
		// delete();
		//joinQuery();
	}

	public static void delete() {
		Configuration cfg = new Configuration();
		cfg.configure();
		SessionFactory sf = cfg.buildSessionFactory();
		Session hsession = sf.openSession();
		Transaction tx = hsession.beginTransaction();

		String hql = "from Author where authorId=?";
		Query query = hsession.createQuery(hql);
		query.setParameter(0, 1);

		List<Author> authors = query.getResultList();
		for (Author a : authors) {
			hsession.delete(a);
		}
		tx.commit();
		hsession.close();
		sf.openSession();
	}

	public static void retrieve() {
		Configuration cfg = new Configuration();
		cfg.configure();
		SessionFactory sf = cfg.buildSessionFactory();
		Session hsession = sf.openSession();

		Author a1 = hsession.get(Author.class, 1);
		System.out.println(a1);
		
		hsession.evict(a1);
		
		Author a2 = hsession.get(Author.class, 1);
		System.out.println(a2);
		

		hsession.close();
		sf.close();

	}

	public static void insert() throws ParseException {

		SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");

		Configuration cfg = new Configuration();
		cfg.configure();
		SessionFactory sf = cfg.buildSessionFactory();
		Session hsession = sf.openSession();
		Transaction tx = hsession.beginTransaction();

		Author a = new Author();
		a.setAuthorName("Cathie siera");
		a.setDob(sdf.parse("10-May-1970"));

		Book b1 = new Book();
		b1.setBookName("J2SE");
		b1.setIsbn("ISBN001");
		b1.setPrice(300.00);
		b1.setAuthor(a);

		Book b2 = new Book();
		b2.setBookName("J2EE");
		b2.setIsbn("ISBN002");
		b2.setPrice(500.00);
		b2.setAuthor(a);

		Set<Book> booksSet = new HashSet<Book>();
		booksSet.add(b1);
		booksSet.add(b2);

		a.setBooks(booksSet);

		hsession.save(a);

		tx.commit();
		hsession.close();
		sf.close();
	}

	public static void joinQuery() {
		Configuration cfg = new Configuration();
		cfg.configure();
		SessionFactory sf = cfg.buildSessionFactory();
		Session hsession = sf.openSession();

		String hql = "SELECT A.authorName,B.bookName FROM Author A " +
					" LEFT OUTER JOIN Book B ON A.authorId=B.author";
		Query query = hsession.createQuery(hql);
		List<Object[]> objArr = query.getResultList();
		for (Object[] obj : objArr) {
			System.out.print(obj[0] + "\t");
			System.out.println(obj[1]);
		}
		hsession.close();
		sf.close();
	}
}
