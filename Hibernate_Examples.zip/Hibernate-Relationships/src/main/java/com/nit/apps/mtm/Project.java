package com.nit.apps.mtm;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import org.hibernate.annotations.Generated;

@Entity
@Table(name = "PROJECTS_MASTER")
public class Project {

	@Id
	@GeneratedValue
	@Column(name = "project_id")
	private Integer projectId;
	@Column(name = "project_name")
	private String projectName;

	@ManyToMany(mappedBy = "projects", cascade = CascadeType.ALL)
	private Set<Employee> employees;

	public Integer getProjectId() {
		return projectId;
	}

	public void setProjectId(Integer projectId) {
		this.projectId = projectId;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public Set<Employee> getEmployees() {
		return employees;
	}

	public void setEmployees(Set<Employee> employees) {
		this.employees = employees;
	}
	
	

}
