package com.nit.apps.oto;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "PERSON_DETAILS")
public class Person {

	@Id
	@GeneratedValue
	@Column(name = "PERSON_ID")
	private Integer personId;

	@Column(name = "PERSON_NAME")
	private String personName;

	@Temporal(TemporalType.DATE)
	@Column(name = "PERSON_DOB")
	private Date dob;

	@Column(name = "PERSON_GENDER")
	private Character gender;

	@OneToOne(cascade = CascadeType.ALL)
	private Passport passport;

	public Integer getPersonId() {
		return personId;
	}

	public void setPersonId(Integer personId) {
		this.personId = personId;
	}

	public String getPersonName() {
		return personName;
	}

	public void setPersonName(String personName) {
		this.personName = personName;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public Character getGender() {
		return gender;
	}

	public void setGender(Character gender) {
		this.gender = gender;
	}

	public Passport getPassport() {
		return passport;
	}

	public void setPassport(Passport passport) {
		this.passport = passport;
	}

	@Override
	public String toString() {
		return "Person [personId=" + personId + ", personName=" + personName
				+ ", dob=" + dob + ", gender=" + gender + ", passport="
				+ passport + "]";
	}

}
