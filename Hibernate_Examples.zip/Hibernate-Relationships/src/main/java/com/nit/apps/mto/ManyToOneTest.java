package com.nit.apps.mto;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class ManyToOneTest {

	public static void main(String[] args) {

		Configuration cfg = new Configuration();
		cfg.configure();
		SessionFactory sf = cfg.buildSessionFactory();
		Session hsession = sf.openSession();
		Transaction tx = hsession.beginTransaction();

		Address a = new Address();
		a.setCity("Hyd");
		a.setState("TG");

		Student s1 = new Student();
		s1.setSname("Student1");
		s1.setAddr(a);

		Student s2 = new Student();
		s2.setSname("Student2");
		s2.setAddr(a);

		hsession.save(s1);
		hsession.save(s2);

		tx.commit();
		hsession.close();
		sf.close();

	}

}
