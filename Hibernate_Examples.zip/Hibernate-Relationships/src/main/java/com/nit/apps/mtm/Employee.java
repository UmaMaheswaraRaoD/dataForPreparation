package com.nit.apps.mtm;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name = "EMP_MASTER")
public class Employee {

	@Id
	@GeneratedValue
	@Column(name = "emp_id")
	private Integer empId;
	@Column(name = "emp_name")
	private String empName;

	@ManyToMany(cascade=CascadeType.ALL)
	@JoinTable(name = "emp_projects",
	  joinColumns = { 
			@JoinColumn(referencedColumnName="emp_id")
	   }, 
	  inverseJoinColumns = {
			@JoinColumn(referencedColumnName="project_id") 
	 }
	)
	private Set<Project> projects;

	public Integer getEmpId() {
		return empId;
	}

	public void setEmpId(Integer empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public Set<Project> getProjects() {
		return projects;
	}

	public void setProjects(Set<Project> projects) {
		this.projects = projects;
	}
	
	

}
