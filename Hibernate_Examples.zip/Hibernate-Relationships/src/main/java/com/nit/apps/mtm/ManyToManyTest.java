package com.nit.apps.mtm;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class ManyToManyTest {

	public static void main(String[] args) {
		Configuration cfg = new Configuration();
		cfg.configure();
		SessionFactory sf = cfg.buildSessionFactory();
		Session hsession = sf.openSession();
		Transaction tx = hsession.beginTransaction();
		
		Employee emp = new Employee();
		emp.setEmpName("Raju");
		
		Project p1 = new Project();
		p1.setProjectName("project-1");
		
		Project p2 = new Project();
		p2.setProjectName("project-2");
		
		Set<Project> projectsSet = new HashSet<Project>();
		projectsSet.add(p1);
		projectsSet.add(p2);
		
		emp.setProjects(projectsSet);
		
		hsession.save(emp);
		
		
		tx.commit();

		hsession.close();

	}

}
