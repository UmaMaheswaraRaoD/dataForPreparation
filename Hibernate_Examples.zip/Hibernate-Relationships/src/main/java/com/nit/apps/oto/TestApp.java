package com.nit.apps.oto;

import java.util.List;

import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class TestApp {

	public static void main(String[] args) throws Exception {
		Configuration cfg = new Configuration();
		cfg.configure();
		SessionFactory sf = cfg.buildSessionFactory();
		Session hsession = sf.openSession();
		
		// Passing procedure name
		StoredProcedureQuery spq = hsession
				.createStoredProcedureQuery("GET_ALL_PRODUCTS_BY_PRICE");
		// registering input parameters
		spq.registerStoredProcedureParameter(1, Double.class, ParameterMode.IN);
		// registering out parameters
		spq.registerStoredProcedureParameter(2, Class.class,
				ParameterMode.REF_CURSOR);
		// setting values for input params
		spq.setParameter(1, 2000.00);
		// executing procedure
		spq.execute();
		// get output parameter value
		List<Object[]> list = spq.getResultList();
		for (Object[] arr : list) {
			System.out.print(arr[0] + "\t");
			System.out.print(arr[1] + "\t");
			System.out.println(arr[2]);
		}
		hsession.close();
		sf.close();
	}
}
