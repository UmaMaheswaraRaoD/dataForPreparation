package com.nit.apps.oto;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "PASSPORT_DETAILS")
public class Passport {

	@Id
	@GeneratedValue
	@Column(name = "PASSPORT_ID")
	private Integer passportId;

	@Column(name = "PASSPORT_NO")
	private String passportNo;

	@Column(name = "ISSUED_DT")
	@Temporal(TemporalType.DATE)
	private Date issuedDt;

	@Column(name = "EXPIRY_DT")
	@Temporal(TemporalType.DATE)
	private Date expiryDt;

	@OneToOne
	@JoinColumn(name = "PERSON_ID")
	private Person person;

	public Integer getPassportId() {
		return passportId;
	}

	public void setPassportId(Integer passportId) {
		this.passportId = passportId;
	}

	public String getPassportNo() {
		return passportNo;
	}

	public void setPassportNo(String passportNo) {
		this.passportNo = passportNo;
	}

	public Date getIssuedDt() {
		return issuedDt;
	}

	public void setIssuedDt(Date issuedDt) {
		this.issuedDt = issuedDt;
	}

	public Date getExpiryDt() {
		return expiryDt;
	}

	public void setExpiryDt(Date expiryDt) {
		this.expiryDt = expiryDt;
	}

	public Person getPerson() {
		return person;
	}

	public void setPerson(Person person) {
		this.person = person;
	}

}
