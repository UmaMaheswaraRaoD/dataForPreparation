package com.nit.apps;

public interface StockMarket {

	public Double getPrice(String name);

}
