package com.nit.apps;

import java.util.ArrayList;
import java.util.List;

import static junit.framework.Assert.*;

import org.easymock.EasyMock;
import org.junit.BeforeClass;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.experimental.categories.Categories.ExcludeCategory;

public class PortfolioTest {

	private static StockMarket market = null;

	@BeforeClass
	public static void setUp() {
		market = EasyMock.createMock(StockMarket.class);
		EasyMock.expect(market.getPrice("amazon")).andReturn(500.00);
		EasyMock.replay(market);
	}

	public void m1() {
		// jcalling dao method
	}

	@Test
	public void testGetTotalPrice() {
		Portfolio pf = new Portfolio();
		pf.setMarket(market);

		Stock s = new Stock();
		s.setName("amazon");
		s.setQuantity(2);
		pf.setStock(s);

		List<Stock> list = new ArrayList<Stock>();
		list.add(s);
		pf.setStocks(list);

		Double actual = pf.getTotalPrice();
		Double expected = 500.00;

		assertEquals(expected, actual);
	}
}
