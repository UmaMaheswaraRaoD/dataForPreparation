package com.nit.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.nit.entities.Customer;

public class CustomerDao {

	public boolean insert(Customer entity) {
		boolean isInserted = false;
		Configuration cfg = new Configuration();
		cfg.configure();
		SessionFactory sf = cfg.buildSessionFactory();
		Session hs = sf.openSession();
		Transaction tx = hs.beginTransaction();
		System.out.println("B4 : " + entity);
		hs.save(entity);
		System.out.println("AFter : " + entity);
		tx.commit();
		hs.close();
		sf.close();
		return true;
	}

	public Customer findById(Integer cid) {
		Configuration cfg = new Configuration();
		cfg.configure();
		SessionFactory sf = cfg.buildSessionFactory();
		Session hs = sf.openSession();
		Customer c = hs.load(Customer.class, cid);
		hs.close();
		return c;
	}

	public boolean update(Customer entity) {
		boolean isUpdated = false;
		try {
			Configuration cfg = new Configuration();
			cfg.configure();
			SessionFactory sf = cfg.buildSessionFactory();
			Session hs = sf.openSession();
			Transaction tx = hs.beginTransaction();
			hs.saveOrUpdate(entity);
			tx.commit();
			hs.close();
			isUpdated = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return isUpdated;

	}

	public boolean delete(Integer cid) {
		boolean isDeleted = false;
		try {
			Configuration cfg = new Configuration();
			cfg.configure();
			SessionFactory sf = cfg.buildSessionFactory();
			Session hs = sf.openSession();
			Transaction tx = hs.beginTransaction();
			Customer c = new Customer();
			//c.setCustomerId(cid);
			hs.delete(c);
			tx.commit();
			isDeleted = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return isDeleted;
	}

	public boolean softDelete(Integer cid) {
		boolean isDeleted = false;
		try {
			Configuration cfg = new Configuration();
			cfg.configure();
			SessionFactory sf = cfg.buildSessionFactory();
			Session hs = sf.openSession();
			Transaction tx = hs.beginTransaction();
			Customer c = hs.get(Customer.class, cid);
			c.setIsActive("N");
			hs.update(c);
			tx.commit();
			isDeleted = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return isDeleted;
	}

}
