package com.nit.test;

import com.nit.dao.CustomerDao;
import com.nit.entities.Customer;

public class CustomerDaoTest {
	public static void main(String[] args) {
		CustomerDao dao = new CustomerDao();
		Customer c = new Customer();
		c.setCustomerName("Raju");
		c.setEmailId("raj@in.com");
		c.setMobileNum(889797979l);
		c.setIsActive("Y");

		boolean isInserted = dao.insert(c);
		if (isInserted) {
			System.out.println("Record inserted...");
		} else {
			System.out.println("Failed to insert..");
		}

		// Customer c = dao.findById(1004);
		// System.out.println(c.getCustomerName());

		// boolean isDeleted = dao.softDelete(105);
		// System.out.println("Deleted : " + isDeleted);
	}
}
