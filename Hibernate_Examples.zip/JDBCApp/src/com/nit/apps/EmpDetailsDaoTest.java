package com.nit.apps;

import java.util.List;

/**
 * This is class is used to EmpDetailsDao functionality
 * @author Ashok
 *
 */
public class EmpDetailsDaoTest {

	public static void main(String[] args) throws Exception {

		EmpDetailsDao dao = new EmpDetailsDao();

		//For inserting record
		/*EmpDetailsDto dto = new EmpDetailsDto(7, "Gita", 4500.00);
		boolean isInserted = dao.insert(dto);
		if (isInserted) {
			System.out.println("record inserteed..");
		} else {
			System.out.println("failed to insert");
		}*/

		//For Selecting record by id
		/*
		 * EmpDetailsDto dto = dao.findByEid(7);
		 *  System.out.println(dto);
		 */

		//Retriving all records
		List<EmpDetailsDto> empsList = dao.findAll();
		for (EmpDetailsDto dto : empsList) {
			System.out.println(dto);
		}

	}
}
