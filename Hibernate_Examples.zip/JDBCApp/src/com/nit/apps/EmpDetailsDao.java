package com.nit.apps;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 * This is class written to perform DB operations
 * with EMP_DETAILS table
 * @author Ashok
 *
 */
public class EmpDetailsDao {

	private static final String DB_DRIVER_CLS = "oracle.jdbc.driver.OracleDriver";
	private static final String DB_URL = "jdbc:oracle:thin:@localhost:1521/XE";
	private static final String DB_UNAME = "system";
	private static final String DB_PWD = "admin";

	private static String SELECT_SQL = "SELECT * FROM EMP_DETAILS";
	private static String EID_WHERE_CLAUSE = " WHERE EMP_ID=?";
	private static String INSERT_SQL = "INSERT INTO EMP_DETAILS VALUES (?,?,?)";

	/**
	 * This method is used to insert a record into table
	 * 
	 * @param dto
	 * @return boolean
	 * @throws Exception
	 */
	public boolean insert(EmpDetailsDto dto) throws Exception {
		Class.forName(DB_DRIVER_CLS);
		Connection con = DriverManager.getConnection(DB_URL, DB_UNAME, DB_PWD);
		PreparedStatement pstmt = con.prepareStatement(INSERT_SQL);

		// setting data to positional parameters
		pstmt.setInt(1, dto.getEid());
		pstmt.setString(2, dto.getEname());
		pstmt.setDouble(3, dto.getEsal());

		int cnt = pstmt.executeUpdate();
		con.close();
		return (cnt > 0) ? true : false;
	}

	/**
	 * This method is used to retrive Emp record with given eid
	 * @param eid
	 * @return EmpDetailsDto
	 * @throws Exception
	 */
	public EmpDetailsDto findByEid(int eid) throws Exception {
		Class.forName(DB_DRIVER_CLS);
		Connection con = DriverManager.getConnection(DB_URL, DB_UNAME, DB_PWD);
		String sql = SELECT_SQL + EID_WHERE_CLAUSE;
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, eid);
		ResultSet rs = pstmt.executeQuery();
		EmpDetailsDto dto = null;
		if (rs.next()) {
			// storing the data into dto object
			dto = new EmpDetailsDto();
			dto.setEid(rs.getInt(1));
			dto.setEname(rs.getString(2));
			dto.setEsal(rs.getDouble(3));
		}
		con.close();
		return dto;
	}

	/**
	 * This method is used to retrieve all the emp records
	 * 
	 * @return List<EmpDetailsDto>
	 * @throws Exception
	 */
	public List<EmpDetailsDto> findAll() throws Exception {
		List<EmpDetailsDto> empList = new ArrayList<EmpDetailsDto>();
		Class.forName(DB_DRIVER_CLS);
		Connection con = DriverManager.getConnection(DB_URL, DB_UNAME, DB_PWD);
		PreparedStatement pstmt = con.prepareStatement(SELECT_SQL);
		ResultSet rs = pstmt.executeQuery();
		while (rs.next()) {
			// Storing data into dto object
			EmpDetailsDto dto = new EmpDetailsDto();
			dto.setEid(rs.getInt(1));
			dto.setEname(rs.getString(2));
			dto.setEsal(rs.getDouble(3));
			// adding every dto in collecttion
			empList.add(dto);
		}
		return empList;
	}
}
