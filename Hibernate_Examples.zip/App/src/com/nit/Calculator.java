package com.nit;

public class Calculator {

	public int add(int i, int j) {
		System.out.println("1stline");
		System.out.println("2nd line..");
		int result = i + j;
		return result;
	}

}
