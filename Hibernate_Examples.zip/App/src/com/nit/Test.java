package com.nit;

public class Test {

	public static void main(String[] args) {
		Calculator c = new Calculator();
		int result = c.add(10, 10);
		System.out.println("Sum is: "+result);
	}

}
