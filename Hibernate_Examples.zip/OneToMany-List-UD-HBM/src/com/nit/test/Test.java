package com.nit.test;

import com.nit.dao.AuthorBookDao;

public class Test {

	public static void main(String[] args) {

		AuthorBookDao dao = new AuthorBookDao();
		dao.saveAuthorWithBooks();
		// dao.findById();
		// dao.findAll();
		//.deleteOneChildOfParent();

	}
}
