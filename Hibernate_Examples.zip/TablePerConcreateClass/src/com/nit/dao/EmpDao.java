package com.nit.dao;

import java.io.Serializable;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.nit.entities.ContractEmployee;
import com.nit.entities.PermanentEmployee;
import com.nit.util.HibernateUtils;

public class EmpDao {

	public void insert(PermanentEmployee pe) {
		Session hs = HibernateUtils.getSession();
		Transaction tx = hs.beginTransaction();
		Serializable id = hs.save(pe);
		System.out.println("Record inserted : " + id);
		tx.commit();
		hs.close();
	}

	public void insert(ContractEmployee pe) {
		Session hs = HibernateUtils.getSession();
		Transaction tx = hs.beginTransaction();
		Serializable id = hs.save(pe);
		System.out.println("Record inserted : " + id);
		tx.commit();
		hs.close();
	}

}
