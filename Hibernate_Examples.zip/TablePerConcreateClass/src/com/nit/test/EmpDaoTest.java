package com.nit.test;

import com.nit.entities.ContractEmployee;
import com.nit.entities.PermanentEmployee;
import com.nit.dao.EmpDao;

public class EmpDaoTest {

	public static void main(String[] args) {
		EmpDao dao = new EmpDao();
		PermanentEmployee pe = new PermanentEmployee();
		pe.setCompanyName("IBM");
		pe.setEmpName("Dean");
		pe.setEmpPhno(79797979l);
		dao.insert(pe);

		ContractEmployee ce = new ContractEmployee();
		ce.setEmpName("Catlin");
		ce.setEmpPhno(79797979l);
		ce.setContractorName("Magna Infotech");
		dao.insert(ce);
	}
}
