package com.nit.dao;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.nit.entities.Author;
import com.nit.entities.Book;
import com.nit.util.HibernateUtils;

public class AuthorBookDao {

	public void saveAuthorWithBooks() {
		// Creating parent object
		Author a = new Author();
		a.setAid(102);
		a.setAuthorName("Gaven King");
		a.setEmail("gk@sun.com");

		// create child1 object
		Book b1 = new Book();
		b1.setBookId(203);
		b1.setBookName("Hibernate");
		b1.setIsbn("ISBN003");
		b1.setPrice(300.00);

		// create child2 object
		Book b2 = new Book();
		b2.setBookId(204);
		b2.setBookName("JPA");
		b2.setIsbn("ISBN004");
		b2.setPrice(400.00);

		// Storing books objs to collection
		Set<Book> books = new HashSet<Book>();
		books.add(b1);
		books.add(b2);

		// Add child objects to Parent
		a.setBooks(books);

		Session hs = HibernateUtils.getSession();
		Transaction tx = hs.beginTransaction();
		// Storing parent object
		hs.save(a);
		System.out.println("Record inserted");
		tx.commit();
		hs.close();
	}

	public void findById() {
		Session hs = HibernateUtils.getSession();
		Author a = (Author) hs.get(Author.class, 101);
		Set<Book> books = a.getBooks();
		for (Book b : books) {
			System.out.println(b);
		}
		hs.close();
	}

	public void findAll() {
		Session hs = HibernateUtils.getSession();
		String hql = "From Author";
		Query query = hs.createQuery(hql);
		List<Author> aList = query.getResultList();
		for (Author a : aList) {
			System.out.println(a);
		}
		hs.close();
	}

	public void deleteOneChildOfParent() {
		Session hs = HibernateUtils.getSession();
		Transaction tx = hs.beginTransaction();
		Author a = (Author) hs.get(Author.class, 102);
		Set<Book> books = a.getBooks();
		Book b = hs.get(Book.class, 203);
		books.remove(b);
		tx.commit();
		hs.close();
	}

	public void deleteAllChilds() {
		Session hs = HibernateUtils.getSession();
		Transaction tx = hs.beginTransaction();
		Author a = (Author) hs.get(Author.class, 101);
		Set<Book> books = a.getBooks();
		books.clear();
		tx.commit();
		hs.close();
	}

}
