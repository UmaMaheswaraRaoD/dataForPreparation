package com.nit.apps;

import java.util.List;

import javax.persistence.Query;

import org.hibernate.Filter;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

public class Test {

	public static void main(String[] args) throws Exception {
		SessionFactory sf = HibernateUtil.getSf();
		Session hsession = sf.openSession();
		Transaction tx = hsession.beginTransaction();

		String hql = "From Product";
		Query query = hsession.createQuery(hql);
		
		Filter f = hsession.enableFilter("price_filter");
		f.setParameter("price", 3000.00);

		List<Product> list = query.getResultList();
		System.out.println(list.size());
		hsession.close();
		sf.close();
	}
}
