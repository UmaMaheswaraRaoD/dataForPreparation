package com.nit.apps;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.hibernate.annotations.Filter;
import org.hibernate.annotations.FilterDef;
import org.hibernate.annotations.ParamDef;

@Entity
@FilterDef(name = "price_filter", parameters = @ParamDef(type = "java.lang.Double", name = "price"))
@Filter(name = "price_filter", condition = "price>=:price")
public class Product {

	@Id
	@GeneratedValue
	private Integer pid;
	private String pname;
	private Double price;

	public Product() {
	}

	public Product(Integer pid, String pname, Double price) {
		this.pid = pid;
		this.pname = pname;
		this.price = price;
	}

	public Integer getPid() {
		return pid;
	}

	public void setPid(Integer pid) {
		this.pid = pid;
	}

	public String getPname() {
		return pname;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

}
