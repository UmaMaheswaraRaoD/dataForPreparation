package com.compositeid.test;

import com.compositeid.dao.ResourceAllocationDao;
import com.composteid.entities.ResourceAllocation;
import com.composteid.entities.ResourceAllocationPK;

public class ResourceAllocationDaoTest {

	public static void main(String[] args) throws Exception {
		ResourceAllocationDao dao = new ResourceAllocationDao();
		ResourceAllocationPK pk = new ResourceAllocationPK();
		pk.setProjectId(302);
		pk.setResourceId(102);
		ResourceAllocation entity = dao.findByIds(pk);
		System.out.println(entity);
	}
}
