package com.composteid.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class ResourceAllocationPK implements Serializable {

	@Column(name = "RESOURCE_ID")
	private Integer resourceId;

	@Column(name = "PROEJCT_ID")
	private Integer projectId;

	public Integer getResourceId() {
		return resourceId;
	}

	public void setResourceId(Integer resourceId) {
		this.resourceId = resourceId;
	}

	public Integer getProjectId() {
		return projectId;
	}

	public void setProjectId(Integer projectId) {
		this.projectId = projectId;
	}

}
