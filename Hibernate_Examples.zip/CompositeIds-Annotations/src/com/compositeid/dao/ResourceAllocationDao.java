package com.compositeid.dao;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.compositeid.util.HibernateUtils;
import com.composteid.entities.ResourceAllocation;
import com.composteid.entities.ResourceAllocationPK;

public class ResourceAllocationDao {

	public void insert(ResourceAllocation ra) {
		Session hs = HibernateUtils.getSession();
		Transaction tx = hs.beginTransaction();

		hs.save(ra);

		tx.commit();
		hs.close();
	}

	public ResourceAllocation findByIds(ResourceAllocationPK pks) {
		Session hs = HibernateUtils.getSession();
		ResourceAllocation entity = hs.get(ResourceAllocation.class, pks);
		hs.close();
		return entity;
	}
}
