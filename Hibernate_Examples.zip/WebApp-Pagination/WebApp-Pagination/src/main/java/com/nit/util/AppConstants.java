package com.nit.util;

public class AppConstants {

}
