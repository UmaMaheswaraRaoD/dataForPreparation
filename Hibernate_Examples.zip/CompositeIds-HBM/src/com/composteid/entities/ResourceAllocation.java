package com.composteid.entities;

import java.io.Serializable;
import java.util.Date;

public class ResourceAllocation implements Serializable{

	private Integer resourceId;
	private Integer projectId;
	private Date allocStartDt;
	private Date allocEndDt;
	private Double allocPercentage;

	public Integer getResourceId() {
		return resourceId;
	}

	public void setResourceId(Integer resourceId) {
		this.resourceId = resourceId;
	}

	public Integer getProjectId() {
		return projectId;
	}

	public void setProjectId(Integer projectId) {
		this.projectId = projectId;
	}

	public Date getAllocStartDt() {
		return allocStartDt;
	}

	public void setAllocStartDt(Date allocStartDt) {
		this.allocStartDt = allocStartDt;
	}

	public Date getAllocEndDt() {
		return allocEndDt;
	}

	public void setAllocEndDt(Date allocEndDt) {
		this.allocEndDt = allocEndDt;
	}

	public Double getAllocPercentage() {
		return allocPercentage;
	}

	public void setAllocPercentage(Double allocPercentage) {
		this.allocPercentage = allocPercentage;
	}

	@Override
	public String toString() {
		return "ResourceAllocation [resourceId=" + resourceId + ", projectId="
				+ projectId + ", allocStartDt=" + allocStartDt
				+ ", allocEndDt=" + allocEndDt + ", allocPercentage="
				+ allocPercentage + "]";
	}

}
