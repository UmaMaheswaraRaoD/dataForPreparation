package com.compositeid.test;

import java.text.SimpleDateFormat;
import java.util.Date;

import com.compositeid.dao.ResourceAllocationDao;
import com.composteid.entities.ResourceAllocation;

public class ResourceAllocationDaoTest {

	public static void main(String[] args) throws Exception {
		ResourceAllocationDao dao = new ResourceAllocationDao();

		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
		Date allocStartDt = sdf.parse("06-12-2017");
		Date allocEndDt = sdf.parse("30-03-2018");

		ResourceAllocation ra = new ResourceAllocation();

		/*
		 * ra.setProjectId(302); ra.setResourceId(102);
		 * ra.setAllocStartDt(allocStartDt); ra.setAllocEndDt(allocEndDt);
		 * ra.setAllocPercentage(50.00);
		 * 
		 * dao.insert(ra);
		 */

		ra.setProjectId(302);
		ra.setResourceId(102);

		ResourceAllocation entity = dao.findByIds(ra);

		System.out.println(entity);

	}

}
