package com.compositeid.dao;

import java.io.Serializable;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.compositeid.util.HibernateUtils;
import com.composteid.entities.ResourceAllocation;

public class ResourceAllocationDao {

	public void insert(ResourceAllocation ra) {
		Session hs = HibernateUtils.getSession();
		Transaction tx = hs.beginTransaction();

		hs.save(ra);

		tx.commit();
		hs.close();
	}

	public ResourceAllocation findByIds(ResourceAllocation entity) {
		Session hs = HibernateUtils.getSession();
		ResourceAllocation model = hs.get(ResourceAllocation.class, entity);
		hs.close();
		return model;
	}

}
