package com.nit.dao;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.nit.entities.Orders;
import com.nit.util.HibernateUtils;

public class OrdersDao {

	public void insert(Orders o) {
		Session hs = HibernateUtils.getSession();
		Transaction tx = hs.beginTransaction();
		Serializable id = hs.save(o);
		tx.commit();
		hs.close();
	}

	public void findAll() {
		Session hs = HibernateUtils.getSession();
		String hql = "From Orders";
		Query query = hs.createQuery(hql);
		query.setFirstResult(0);
		query.setMaxResults(3);
		List<Orders> list = query.getResultList();
		for (Orders o : list) {
			System.out.println(o);
		}
		hs.close();
	}

	public void findById(String orderId) {
		Session hs = HibernateUtils.getSession();
		String hql = "From Orders where orderId=?";
		Query query = hs.createQuery(hql);
		query.setParameter(0, orderId);
		List<Orders> list = query.getResultList();
		for (Orders o : list) {
			System.out.println(o);
		}
		hs.close();
	}

	public void findByEmail(String email, String name) {
		Session hs = HibernateUtils.getSession();
		String hql = "From Orders where orderBy=:name and orderPersonEmail=:email";
		Query query = hs.createQuery(hql);
		query.setParameter("email", email);
		query.setParameter("name", name);
		List<Orders> list = query.getResultList();
		for (Orders o : list) {
			System.out.println(o);
		}
		hs.close();
	}

	public void findNameById(String orderId) {
		Session hs = HibernateUtils.getSession();
		String hql = "select orderBy,orderPersonEmail from Orders where orderId=:id";
		Query query = hs.createQuery(hql);
		query.setParameter("id", orderId);
		List<Object[]> listArr = (List<Object[]>) query.getResultList();
		for (Object[] arr : listArr) {
			System.out.println(arr[0]);
			System.out.println(arr[1]);

		}
		hs.close();
	}

	public void findTotalRecords() {
		Session hs = HibernateUtils.getSession();
		String hql = "select count(*) from Orders";
		Query query = hs.createQuery(hql);
		List<Long> list = (List<Long>) query.getResultList();
		if (!list.isEmpty()) {
			System.out.println(list.get(0));
		}
		hs.close();
	}

	public void updateMailById(String id, String email) {
		Session hs = HibernateUtils.getSession();
		Transaction tx = hs.beginTransaction();
		String hql = "update Orders set orderPersonEmail=:email where orderId=:id";
		Query query = hs.createQuery(hql);
		query.setParameter("email", email);
		query.setParameter("id", id);

		query.executeUpdate();

		tx.commit();
		hs.close();
	}
}
