package com.nit.test;

import com.nit.dao.OrdersDao;

public class OrdersDaoTest {

	public static void main(String[] args) {
		OrdersDao dao = new OrdersDao();
		 //dao.findAll();
		// dao.findById("OD2");
		//dao.findByEmail("mahesh@In.com","Mahesh");
		//dao.findNameById("OD2");
		//dao.findTotalRecords();
		dao.updateMailById("OD1", "rajkumar@In.com");
	}
}
