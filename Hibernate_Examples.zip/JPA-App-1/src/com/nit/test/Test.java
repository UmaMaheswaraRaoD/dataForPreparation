package com.nit.test;

import java.util.List;

import javax.persistence.EntityGraph;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.criteria.CriteriaQuery;

import com.nit.entities.Orders;

public class Test {
	public static void main(String[] args) {
		// retriveById();
		findAll();
	}

	public static void findAll() {
		EntityManagerFactory factory = Persistence
				.createEntityManagerFactory("JPA-App-1");
		EntityManager manager = factory.createEntityManager();
		String jpql = "From Orders";
		Query query = manager.createQuery(jpql);
		List<Orders> list = query.getResultList();
		for (Orders o : list) {
			System.out.println(o);
		}
		manager.close();
		factory.close();

	}

	public static void retriveById() {
		EntityManagerFactory factory = Persistence
				.createEntityManagerFactory("JPA-App-1");
		EntityManager manager = factory.createEntityManager();

		Orders od = manager.find(Orders.class, "OD1");
		System.out.println(od);
		manager.close();
		factory.close();

	}

	public void insert() {

		EntityManagerFactory factory = Persistence
				.createEntityManagerFactory("JPA-App-1");
		EntityManager manager = factory.createEntityManager();

		manager.getTransaction().begin();

		Orders od = new Orders();
		od.setOrderBy("Mahesh");
		od.setOrderId("OD25");
		od.setOrderPersonEmail("mahi@In.com");

		manager.persist(od);

		manager.getTransaction().commit();

		manager.find(Orders.class, "OD1");
		manager.close();
		factory.close();

	}
}
