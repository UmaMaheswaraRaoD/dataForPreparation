package com.nit.test;

import com.hib.entities.Robot;
import com.nit.dao.RobotDao;

public class RobotDaoTest {
	public static void main(String[] args) {

		Robot r = new Robot();
		r.setName("Chitti-2.0");
		r.setType("Entertainement");

		RobotDao dao = new RobotDao();
		dao.insert(r);
	}
}
