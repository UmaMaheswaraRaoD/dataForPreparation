package com.nit.apps;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

public class TestApp {

	public static void main(String[] args) throws Exception {
		Configuration cfg = new Configuration();
		cfg.configure();
		SessionFactory sf = cfg.buildSessionFactory();
		Session hsession1 = sf.openSession();

		String hql = "From Person";

		Query query = hsession1.createQuery(hql);
		query.setCacheable(true);

		List<Person> pList = query.getResultList();
		for (Person p : pList) {
			System.out.println(p);
		}
		
		Query query1 = hsession1.createQuery(hql);
		query1.setCacheable(true);

		List<Person> pList1 = query1.getResultList();
		for (Person p : pList1) {
			System.out.println(p);
		}
		hsession1.close();
		sf.close();
	}
}
