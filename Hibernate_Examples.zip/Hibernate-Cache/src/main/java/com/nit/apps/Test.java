package com.nit.apps;

public class Test {
	
	public static void main(String[] args) {
		
		User u1 = User.getInstance();
		User u2 = User.getInstance();
		
		System.out.println(u1==u2);
	}

}
