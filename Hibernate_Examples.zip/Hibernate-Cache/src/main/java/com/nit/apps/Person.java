package com.nit.apps;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

@Entity
@Table(name = "PERSON_DETAILS")
@Cache(
		region = "person", 
		usage = CacheConcurrencyStrategy.READ_ONLY
 )
public class Person {

	@Id
	@GeneratedValue
	@Column(name = "PERSON_ID")
	private Integer personId;

	@Column(name = "PERSON_NAME")
	private String personName;

	@Column(name = "PERSON_GENDER")
	private Character gender;

	public Integer getPersonId() {
		return personId;
	}

	public void setPersonId(Integer personId) {
		this.personId = personId;
	}

	public String getPersonName() {
		return personName;
	}

	public void setPersonName(String personName) {
		this.personName = personName;
	}

	public Character getGender() {
		return gender;
	}

	public void setGender(Character gender) {
		this.gender = gender;
	}

	@Override
	public String toString() {
		return "Person [personId=" + personId + ", personName=" + personName
				+ ", gender=" + gender + "]";
	}

}
