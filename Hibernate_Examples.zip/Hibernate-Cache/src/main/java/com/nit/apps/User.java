package com.nit.apps;

public class User {

	// static variable
	private static User instance = null;

	// private Constructor
	private User() {
	}

	// static method
	public static User getInstance() {
		if (instance == null) {
			synchronized (instance) {
				if (instance == null) {
					instance = new User();
				}
			}
		}
		return instance;
	}
}
