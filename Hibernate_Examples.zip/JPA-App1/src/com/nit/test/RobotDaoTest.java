package com.nit.test;

import com.hib.entities.Robot;
import com.nit.dao.RobotDao;

public class RobotDaoTest {
	public static void main(String[] args) {

		Robot r = new Robot();
		r.setName("New Robot");
		r.setType("Industrial");

		RobotDao dao = new RobotDao();
		// dao.insert(r);
		//dao.findById(43);
		dao.findAll();
		
	}
}
