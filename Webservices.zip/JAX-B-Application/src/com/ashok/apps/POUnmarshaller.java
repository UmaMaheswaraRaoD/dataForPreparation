package com.ashok.apps;

import java.io.File;

import javax.xml.XMLConstants;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;

import com.ebay.sales.types.bindings.PurchaseOrderType;

public class POUnmarshaller {

	public static void main(String[] args) throws Exception {

		JAXBContext context = JAXBContext.newInstance(PurchaseOrderType.class);

		SchemaFactory factory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
		Schema schema = factory.newSchema(new File("po.xsd"));
		Validator validator = schema.newValidator();
		validator.validate(new StreamSource("po.xml"));

		Unmarshaller unmarshaller = context.createUnmarshaller();

		PurchaseOrderType poType = (PurchaseOrderType) unmarshaller.unmarshal(new File("po.xml"));

		System.out.println(poType.getOrderItems().getItem().get(0)
				.getItemCode());
	}

}
