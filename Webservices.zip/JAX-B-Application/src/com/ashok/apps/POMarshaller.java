package com.ashok.apps;

import java.io.File;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;

import com.ebay.sales.types.bindings.ItemType;
import com.ebay.sales.types.bindings.OrderItemsType;
import com.ebay.sales.types.bindings.PurchaseOrderType;
import com.ebay.sales.types.bindings.ShippingAddressType;

public class POMarshaller {

	public static void main(String[] args) throws Exception {

		JAXBContext context = JAXBContext.newInstance(PurchaseOrderType.class);
		Marshaller marshaller = context.createMarshaller();
		marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
		marshaller.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");
		marshaller.marshal(getPOData(), new File("Marshall-PO.xml"));
		marshaller.marshal(getPOData(), System.out);
	}

	public static PurchaseOrderType getPOData() {
		PurchaseOrderType po = new PurchaseOrderType();

		ItemType it1 = new ItemType();
		it1.setItemCode("IC202");
		it1.setQuantity(20);

		OrderItemsType ot = new OrderItemsType();
		ot.getItem().add(it1);

		ShippingAddressType addrType = new ShippingAddressType();
		addrType.setAddressLine1("SR Nagar");
		addrType.setAddressLine2("Ameerpet");
		addrType.setCity("Hyderabad");
		addrType.setState("TG");
		addrType.setCountry("India");
		addrType.setZip(5797990);
		addrType.setType("Permanent");

		po.setOrderItems(ot);
		po.setShippingAddress(addrType);

		return po;
	}
}
