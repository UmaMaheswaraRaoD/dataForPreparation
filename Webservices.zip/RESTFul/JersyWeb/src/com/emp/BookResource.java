package com.emp;

import javax.ws.rs.core.Response;

public interface BookResource {

	public Response getPrice(String isbn);

}
