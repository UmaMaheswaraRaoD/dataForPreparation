package com.emp;

import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.Path;
import javax.ws.rs.core.Response;

@Path("/header")
public class HeaderResource {

	@GET
	public Response queryHeaderInfo(
			@HeaderParam("Cache-Control") String cacheControl,
			@HeaderParam("User-Agent") String uagent) {
		String msg = "Cache Control : " + cacheControl;
		msg = msg+" User agent : "+uagent;
		return Response.ok(msg).build();
	}
}