package com.emp;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

@Path("/emp")
public class EmployeeResource {

	@GET
	@Path("/query")
	public Response getEmployee(@Context UriInfo uri) {
		List<String> ids = uri.getQueryParameters().get("id");
		String msg = "Employee Ids : " + ids;
		return Response.ok(msg).build();
	}
	
	@GET
	@Path("/getName/{id}")
	public Response getName(@PathParam("id")String id) {
		String msg = "Employee Id : " + id;
		return Response.ok(msg).build();
	}

}
