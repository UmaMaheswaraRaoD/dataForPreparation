package com.emp;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Response;

@Path("/book")
public class BookResourceImpl implements BookResource {

	@Override
	@GET
	@Path("/price/{isbn}")
	public Response getPrice(@PathParam("isbn") String isbn) {
		return Response.ok("Price : 100").build();
	}
}
