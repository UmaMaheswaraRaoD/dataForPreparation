package com.rest.resources.clients;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

public class QueryParamCarResourceHttpClient {
	public static void main(String[] args) throws Exception {

		DefaultHttpClient client = new DefaultHttpClient();

		HttpGet getRequest = new HttpGet("http://localhost:6060/JersyWeb-Injection/rest/query-car/availability?name=Swift");

		HttpResponse response = client.execute(getRequest);

		if(response.getStatusLine().getStatusCode()!=200){
			System.out.println("Unable to Invoke the Resource");
		}else{
			InputStream is = response.getEntity().getContent();
			BufferedReader br = new BufferedReader(new InputStreamReader(is));
			System.out.println("Response : "+br.readLine());
		}
	}
}
