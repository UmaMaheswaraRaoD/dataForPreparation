package com.rest.resources.clients;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import org.glassfish.jersey.message.internal.InputStreamProvider;

public class PathParamBookResourceClientWithURL {
	public static void main(String[] args) throws Exception {

		URL url = new URL(
				"http://localhost:6060/JersyWeb-Injection/rest/bookstore/price/ISBN001");
		HttpURLConnection httpCon = (HttpURLConnection) url.openConnection();
		httpCon.setRequestMethod("GET");

		int respCode= httpCon.getResponseCode();
		if(respCode!=200){
			System.out.println("Unable to Invoke the Resource");
		}else{
			BufferedReader br = 
					new BufferedReader(new InputStreamReader(httpCon.getInputStream()));
			System.out.println("Response : "+br.readLine());
		}
	}
}
