package com.rest.resources;

import javax.ws.rs.BeanParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.Response;

import com.rest.domain.Student;

@Path("/student")
public class BeanParamStudentResource {

	@POST
	@Path("/addStudent")
	public Response addStudent(@BeanParam Student s) {
		System.out.println(s);
		return Response.ok("Addedd").build();
	}

}
