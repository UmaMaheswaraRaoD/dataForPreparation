package com.rest.resources;

import javax.ws.rs.BeanParam;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.MatrixParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;

import com.rest.domain.Book;


@Path("/book")
public class BookResource {
	

	@GET
	@Path("/price/{isbn}")
	public Response getBookPrice(@PathParam("isbn") String isbn) {
		String msg = "Book price is $450.00";
		return Response.ok(msg).build();
	}
	
	@GET
	@Path("/getName")
	public Response getBookName(@QueryParam("isbn") String isbn) {
		String msg = "Book Name is Spring Pro For ISBN : "+isbn;
		return Response.ok(msg).build();
	}

	@GET
	@Path("/bookNameByAuthor")
	public Response getBookNameByAuthor(@MatrixParam("author") String author) {
		String msg = author + " Published Book Name is Spring Pro";
		return Response.ok(msg).build();
	}
	
	@POST
	@Path("/addBook")
	public Response addBook(@FormParam("isbn") String isbn, @FormParam("name") String name,@FormParam("author") String author){
		String msg = "Book Added with ISBN : "+isbn+", Book Name : "+name+", Author : "+author;
		return Response.ok(msg).build();
	}
	
	@POST
	@Path("/addBookWithBean")
	public Response addBook(@BeanParam Book b){
		String msg = "Book Added with ISBN : "+b.getIsbn()+", Book Name : "+b.getName()+", Author : "+b.getAuthor();
		return Response.ok(msg).build();
	}
}
