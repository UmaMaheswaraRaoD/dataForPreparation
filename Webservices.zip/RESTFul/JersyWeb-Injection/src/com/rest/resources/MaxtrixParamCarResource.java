package com.rest.resources;

import javax.ws.rs.GET;
import javax.ws.rs.MatrixParam;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;

@Path("/matrix-car")
public class MaxtrixParamCarResource {

	@GET
	@Path("/order/{brand}/{model}")
	public String orderCar(@PathParam("brand") String brand, @PathParam("model") int model,@MatrixParam("color") String color) {
		System.out.println("Brand : "+brand);
		System.out.println("Model : "+model);
		System.out.println("Color : "+color);
		return "Car orderd successfully..!";
	}

}
