package com.mynthra.resources;

import java.util.UUID;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.mynthra.domain.OrderInfo;

@Path("/order")
public class OrderResource {

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/placeOrder")
	public Response placeOrder(OrderInfo orderInfo) {
		System.out.println(orderInfo);
		String msg = "Order Placed with Order Id : " + orderInfo.getOrderId();
		return Response.ok(msg).build();
	}

	@GET
	@Path("/getOrderInfo/{oid}")
	@Produces(MediaType.APPLICATION_JSON)
	public OrderInfo getOrderDetails(@PathParam("oid") String oid) {
		OrderInfo oinfo = new OrderInfo();
		oinfo.setOrderId(oid);
		oinfo.setItemCode("ICOO1");
		oinfo.setItemQuantity(10);
		oinfo.setCity("Hyd");
		oinfo.setState("TG");
		oinfo.setCountry("India");
		return oinfo;
	}

}
