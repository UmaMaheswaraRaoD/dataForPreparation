package com.mynthra.resources.client;

import javax.ws.rs.core.MediaType;

import org.codehaus.jackson.map.ObjectMapper;

import com.mynthra.domain.OrderInfo;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

public class OrderResourceClient {

	private static final String ORDER_INFO_REQUEST_URL = "http://localhost:6060/JersyWeb-Json-Jackson/rest/order/getOrderInfo/101";
	private static final String PLACE_ORDER_REQUEST_URL = "http://localhost:6060/JersyWeb-Json-Jackson/rest/order/placeOrder";

	public static void main(String[] args) throws Exception {
		OrderResourceClient client = new OrderResourceClient();
		client.placeOrder();
		client.getOrderInfo();
	}

	public void getOrderInfo() {
		Client client = Client.create();
		WebResource resource = client.resource(ORDER_INFO_REQUEST_URL);
		OrderInfo orderInfoRes = resource.accept("application/json").get(
				OrderInfo.class);
		System.out.println(orderInfoRes);

	}

	public void placeOrder() throws Exception {

		OrderInfo info = new OrderInfo();
		info.setOrderId("OD1203");
		info.setItemCode("ICoo1");
		info.setItemQuantity(10);
		info.setCity("Hyd");
		info.setState("TG");
		info.setCountry("India");

		/*
		 * String inputData =
		 * "{\"itemCode\":\"ICOO1\",\"itemQuantity\":10,\"city\":\"Hyd\",\"state\":\"TG\",\"country\":\"India\",\"order-id\":\"101\"}"
		 * ;
		 */
		ObjectMapper mapper = new ObjectMapper();
		String inputData = mapper.writeValueAsString(info);

		Client client = Client.create();
		
		WebResource resource = client.resource(PLACE_ORDER_REQUEST_URL);
		
		
		ClientResponse response = resource.type(MediaType.APPLICATION_JSON)
				.post(ClientResponse.class, inputData);

		System.out.println("Output from Server .... \n");
		String output = response.getEntity(String.class);
		System.out.println(output);

	}
}
