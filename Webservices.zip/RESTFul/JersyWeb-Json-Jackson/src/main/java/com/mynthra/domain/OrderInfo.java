package com.mynthra.domain;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "order-info")
@XmlAccessorType(XmlAccessType.FIELD)
public class OrderInfo {

	private String orderId;
	private String itemCode;
	private Integer itemQuantity;
	private String city;
	private String state;
	private String country;

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getItemCode() {
		return itemCode;
	}

	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}

	public Integer getItemQuantity() {
		return itemQuantity;
	}

	public void setItemQuantity(Integer itemQuantity) {
		this.itemQuantity = itemQuantity;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	@Override
	public String toString() {
		return "OrderInfo [orderId=" + orderId + ", itemCode=" + itemCode
				+ ", itemQuantity=" + itemQuantity + ", city=" + city
				+ ", state=" + state + ", country=" + country + "]";
	}

}
