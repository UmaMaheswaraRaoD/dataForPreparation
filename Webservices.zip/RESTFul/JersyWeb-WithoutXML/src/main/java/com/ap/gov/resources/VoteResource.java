package com.ap.gov.resources;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/voter")
public class VoteResource {

	@Path("/inputstream")
	@POST
	@Consumes(MediaType.TEXT_PLAIN)
	@Produces(MediaType.TEXT_PLAIN)
	public String addVote(InputStream is) throws IOException {
		int c = 0;
		StringBuffer buffer = new StringBuffer();
		BufferedInputStream bis = new BufferedInputStream(is);
		while ((c = bis.read()) != -1) {
			buffer.append((char) c);
		}
		return buffer.toString();
	}

	@Path("/reader")
	@POST
	@Consumes(MediaType.TEXT_PLAIN)
	@Produces(MediaType.TEXT_PLAIN)
	public String addVote(Reader r) throws IOException {
		StringBuffer buffer = new StringBuffer();
		BufferedReader br = new BufferedReader(r);
		String line = br.readLine();
		while (line != null) {
			buffer.append(line);
			line = br.readLine();
		}
		return buffer.toString();
	}

	@Path("/byte")
	@POST
	@Produces(MediaType.TEXT_PLAIN)
	@Consumes(MediaType.TEXT_PLAIN)
	public String addVote(byte[] body) {
		StringBuffer buffer = null;
		buffer = new StringBuffer();
		if (body != null && body.length > 0) {
			for (byte b : body) {
				buffer.append((char) b);
			}
		}
		return buffer.toString();
	}

	@GET
	@Produces(MediaType.APPLICATION_XML)
	@Path("/quote")
	public byte[] getDailyQuote() {
		String responseBody = null;
		responseBody = "<quote><msg>Don't Drink and Drive..!!</msg></quote>";
		return responseBody.getBytes();
	}

}
