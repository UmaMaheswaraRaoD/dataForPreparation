package com.restapps.resources.clients;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import com.restapps.domain.Customer;

public class CustomerResourceClient {

	private final static String GET_CUSTOMER_RESOURCE_URI = "http://localhost:6060/JersyWeb-JAXB-XML/rest/customers/getCustomer/101";
	private final static String ADD_CUSTOMER_RESOURCE_URI = "http://localhost:6060/JersyWeb-JAXB-XML/rest/customers";

	public static void main(String[] args) {

		CustomerResourceClient client = new CustomerResourceClient();
		client.getCustomer();
		// client.addCustomer();
	}

	public void getCustomer() {
		Client client = null;
		ClientBuilder builder = null;
		WebTarget target = null;

		client = builder.newClient();
		target = client.target(GET_CUSTOMER_RESOURCE_URI);

		Customer c = target.request().get(Customer.class);
		System.out.println(c);
	}

	public void addCustomer() {
		Customer c = new Customer();
		c.setCid(101);
		c.setCname("ashok");

		Client client = ClientBuilder.newClient();

		WebTarget target = client.target(ADD_CUSTOMER_RESOURCE_URI).path(
				"addCustomer");

		Response response = target.request().post(
				Entity.entity(c, MediaType.APPLICATION_XML));

		if (response.getStatus() == Status.OK.getStatusCode()) {
			String responseString = response.readEntity(String.class);
			System.out.println("Response from Resource : " + responseString);
		}

	}
}
