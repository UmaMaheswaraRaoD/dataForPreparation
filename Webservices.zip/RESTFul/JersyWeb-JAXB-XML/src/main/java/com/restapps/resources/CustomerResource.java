package com.restapps.resources;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.restapps.domain.Customer;

@Path("/customers")
public class CustomerResource {

	@GET
	@Path("/getCustomer/{cid}")
	@Produces(MediaType.APPLICATION_XML)
	public Customer getCusotmer(@PathParam("cid") String cid) {
		Customer c = new Customer();
		c.setCid(101);
		c.setCname("Robert");
		c.setCemail("robert@gmail.com");
		c.setCphno("979797979");
		return c;
	}

	@POST
	@Path("/addCustomer")
	@Consumes(MediaType.APPLICATION_XML)
	public Response addCustomer(Customer c) {
		System.out.println(c);
		String msg = "Customer added succesfully..!!";
		return Response.ok(msg).build();
	}

}
