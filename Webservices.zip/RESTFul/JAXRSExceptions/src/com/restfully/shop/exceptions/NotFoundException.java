package com.restfully.shop.exceptions;
public class NotFoundException extends RuntimeException{
	public NotFoundException(){ super(); }	
    public NotFoundException(String s){ super(s);}
}
