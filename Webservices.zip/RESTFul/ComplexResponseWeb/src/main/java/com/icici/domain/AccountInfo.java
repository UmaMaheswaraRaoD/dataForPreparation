package com.icici.domain;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "account")
@XmlAccessorType(XmlAccessType.FIELD)
public class AccountInfo {

	private Long accNo;

	private String holderName;

	private String branchName;

	private String accType;

	private String txLimit;

	public Long getAccNo() {
		return accNo;
	}

	public void setAccNo(Long accNo) {
		this.accNo = accNo;
	}

	public String getHolderName() {
		return holderName;
	}

	public void setHolderName(String holderName) {
		this.holderName = holderName;
	}

	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	public String getAccType() {
		return accType;
	}

	public void setAccType(String accType) {
		this.accType = accType;
	}

	public String getTxLimit() {
		return txLimit;
	}

	public void setTxLimit(String txLimit) {
		this.txLimit = txLimit;
	}

	@Override
	public String toString() {
		return "AccountInfo [accNo=" + accNo + ", holderName=" + holderName
				+ ", branchName=" + branchName + ", accType=" + accType
				+ ", txLimit=" + txLimit + "]";
	}

}
