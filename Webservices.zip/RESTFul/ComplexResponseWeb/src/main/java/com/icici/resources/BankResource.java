package com.icici.resources;

import java.net.URI;
import java.net.URISyntaxException;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;
import javax.ws.rs.core.Response.Status;

import com.icici.domain.AccountInfo;
import com.icici.domain.PersonInfo;

@Path("/bank")
public class BankResource {

	@GET
	@Path("/getBalance/{accNo}")
	@Produces(MediaType.TEXT_PLAIN)
	public Response getBalance(@PathParam("accNo") String accNo) {
		Response resp = null;
		ResponseBuilder builder = null;

		builder = Response.ok("The Balance for acc no : " + accNo
				+ " Is 4500.00 ");
		resp = builder.build();
		return resp;
	}

	@POST
	@Path("/createAccount")
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	public Response createAccount(PersonInfo pinfo) throws URISyntaxException {
		System.out.println(pinfo);
		Response resp = null;
		ResponseBuilder builder = null;
		builder = Response.created(new URI("/rest/bank/createAccount"));
		resp = builder.build();
		return resp;
	}

	@PUT
	@Path("/upgradeAcc")
	@Consumes(MediaType.APPLICATION_XML)
	public Response upgradeAccount(AccountInfo accInfo) {
		Response resp = null;
		ResponseBuilder builder = null;
		System.out.println(accInfo);
		builder = Response.status(Status.NO_CONTENT);
		resp = builder.build();
		return resp;
	}

	@GET
	@Path("/getAccInfo/{accNo}")
	@Produces({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	public AccountInfo getAccDetails(@PathParam("accNo") String accNo) {
		AccountInfo accInfo = new AccountInfo();
		
		//Setting Accout Info 
		accInfo.setAccNo(Long.parseLong(accNo));
		accInfo.setHolderName("Ashok");
		accInfo.setAccType("Savings");
		accInfo.setBranchName("S.R.Nagar");
		accInfo.setTxLimit("40,000");

		return accInfo;

	}

}
