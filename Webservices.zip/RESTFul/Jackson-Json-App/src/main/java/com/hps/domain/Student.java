package com.hps.domain;

import java.util.Date;

import org.codehaus.jackson.map.annotate.JsonSerialize;

public class Student {

	private Integer studentId;

	private String studentName;

	private String studentEmail;

	private Long studentRank;

	@JsonSerialize(using=DateSerializer.class)
	private Date dob;

	public Integer getStudentId() {
		return studentId;
	}

	public void setStudentId(Integer studentId) {
		this.studentId = studentId;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public String getStudentEmail() {
		return studentEmail;
	}

	public void setStudentEmail(String studentEmail) {
		this.studentEmail = studentEmail;
	}

	public Long getStudentRank() {
		return studentRank;
	}

	public void setStudentRank(Long studentRank) {
		this.studentRank = studentRank;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	@Override
	public String toString() {
		return "Student [studentId=" + studentId + ", studentName="
				+ studentName + ", studentEmail=" + studentEmail
				+ ", studentRank=" + studentRank + ", dob=" + dob + "]";
	}

}
