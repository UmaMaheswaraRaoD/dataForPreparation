package com.hps.converters;

import java.io.FileReader;

import org.codehaus.jackson.map.ObjectMapper;

import com.hps.domain.Student;

public class JsonToObjectConverter {

	public static void main(String[] args) throws Exception {

		FileReader fr = new FileReader("Student-Data.json");

		ObjectMapper mapper = new ObjectMapper();
		
		Student s = mapper.readValue(fr, Student.class);
		System.out.println(s);
		fr.close();

	}

}
