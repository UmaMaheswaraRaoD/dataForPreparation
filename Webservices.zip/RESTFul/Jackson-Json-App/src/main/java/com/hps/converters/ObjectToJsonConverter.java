package com.hps.converters;

import java.util.Date;

import org.codehaus.jackson.map.ObjectMapper;

import com.hps.domain.Student;

public class ObjectToJsonConverter {

	public static void main(String[] args) throws Exception {

		Student s = new Student();
		s.setStudentId(1001);
		s.setStudentName("Raja");
		s.setStudentEmail("raja@gmail.com");
		s.setStudentRank(1200l);
		s.setDob(new Date());

		ObjectMapper mapper = new ObjectMapper();
		
		String jsonStr = mapper.writeValueAsString(s);
		System.out.println(jsonStr);
		
		System.out.println("==============");
		String json = mapper.defaultPrettyPrintingWriter().writeValueAsString(s);
		System.out.println(json);
	}

}
