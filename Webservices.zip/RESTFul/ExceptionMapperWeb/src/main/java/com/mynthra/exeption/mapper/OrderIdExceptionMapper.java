package com.mynthra.exeption.mapper;

import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;

import com.mynthra.exeption.OrderIdNotFoundException;

public class OrderIdExceptionMapper implements
		ExceptionMapper<OrderIdNotFoundException> {

	public Response toResponse(OrderIdNotFoundException ex) {
		return Response.status(400)
				.entity(ex.getMessage())
				.build();
	}
}
