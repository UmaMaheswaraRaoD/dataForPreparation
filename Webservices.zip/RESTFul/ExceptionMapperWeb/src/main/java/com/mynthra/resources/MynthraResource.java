package com.mynthra.resources;

import java.net.URI;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

import com.mynthra.domain.OrderInfo;
import com.mynthra.exeption.OrderIdNotFoundException;

@Path("/mynthra")
public class MynthraResource {

	private Map<String, OrderInfo> ordersMap = null;

	public MynthraResource() {
		System.out.println("*********MynthraResource:constructor**********");
		ordersMap = new HashMap<String, OrderInfo>();
	}

	@POST
	@Path("/placeOrder")
	@Consumes(MediaType.APPLICATION_XML)
	public Response placeOrder(OrderInfo oinfo) throws Exception {
		Response resp = null;
		ResponseBuilder builder = null;

		String itemCode = oinfo.getItemCode();
		if (itemCode != null && !itemCode.equals("")) {
			String orderId = UUID.randomUUID().toString();
			oinfo.setOrderId(orderId);

			// Storing orders in in-memory map
			ordersMap.put(orderId, oinfo);

			// logic to place the order
			// Returing response to client
			builder = Response.created(new URI("/rest/mynthra/placeOrder"));
			resp = builder.build();

			System.out.println(ordersMap);

		} else {
			// throw new Exception("ItemCode is mandatory");
			throw new WebApplicationException(400);
		}

		return resp;
	}

	@GET
	@Path("/trackOrder")
	@Produces(MediaType.APPLICATION_XML)
	public Response trackOrder(@QueryParam("oid") String oid)
			throws OrderIdNotFoundException {

		Response resp = null;
		ResponseBuilder builder = null;

		OrderInfo info = null;
		System.out.println("OID : " + oid);
		if (ordersMap.containsKey(oid)) {
			//Order Id matched, return the status 
			info = ordersMap.get(oid);
			info.setOrderStatus("Ready to Dispatch");
			builder = Response.ok(info);
			resp = builder.build();
		} else {
			// Order Id is not available throw exception
			throw new OrderIdNotFoundException(
					"Order Id is mandatory for tracking..!!");
		}

		return resp;
	}
}
