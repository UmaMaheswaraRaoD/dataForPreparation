package com.mynthra.exeption;

public class OrderIdNotFoundException extends Exception {

	private static final long serialVersionUID = 1465283740319337402L;

	public OrderIdNotFoundException() {
		super();
	}

	public OrderIdNotFoundException(String msg) {
		super(msg);
	}

}
