package com.mynthra.config;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

import com.mynthra.exeption.mapper.OrderIdExceptionMapper;
import com.mynthra.resources.MynthraResource;

@ApplicationPath("/rest/*")
public class AppConfig extends Application {

	Set<Object> singletons = new HashSet<Object>();
	Set<Class<?>> classes = new HashSet<Class<?>>();
	
	@Override
	public Set<Object> getSingletons() {
		singletons.add(new MynthraResource());
		return singletons;
	}
	
	@Override
	public Set<Class<?>> getClasses() {
		classes.add(OrderIdExceptionMapper.class);
		return classes;
	}

	@Override
	public Map<String, Object> getProperties() {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("jersey.config.server.provider.packages",
				"com.mynthra.resources");
		return map;
	}

}
