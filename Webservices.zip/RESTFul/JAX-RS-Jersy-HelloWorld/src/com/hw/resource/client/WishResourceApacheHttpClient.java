package com.hw.resource.client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;

public class WishResourceApacheHttpClient {
	private static final String RESOURCE_URI = "http://localhost:6060/JAX-RS-Jersy-HelloWorld/rest/wish/wish/Ashok";

	public static void main(String[] args) throws ClientProtocolException,
			IOException {

		HttpClient client = HttpClientBuilder.create().build();

		HttpGet getReq = new HttpGet(RESOURCE_URI);
		
		HttpResponse response = client.execute(getReq);
		
		InputStream is = response.getEntity().getContent();
		
		BufferedReader br = new BufferedReader(new InputStreamReader(is));
		
		System.out.println(br.readLine());
	}
}
