package com.hw.resource.client;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class WishResourceURLClient {

	private static final String RESOURCE_URI = "http://localhost:6060/JAX-RS-Jersy-HelloWorld/rest/wish/wish/Ashok";

	public static void main(String[] args) throws Exception {
		URL url = new URL(RESOURCE_URI);
		HttpURLConnection httpCon = (HttpURLConnection) url.openConnection();

		int statusCode = httpCon.getResponseCode();
		if (statusCode == 200) {
			// Resource processed request successfully
			InputStream is = httpCon.getInputStream();
			BufferedReader br = new BufferedReader(new InputStreamReader(is));
			String resString = br.readLine();
			System.out.println("******Server Response********");
			System.out.println(resString);
		} else {
			// Resource response is not correct
			System.out.println("Failed to process the request");
		}
	}

}
