package com.hw.resource.client;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;

public class WishResourceJersyClient {
	private static final String RESOURCE_URI = "http://localhost:6060/JAX-RS-Jersy-HelloWorld/rest/wish/wish/Ashok";

	public static void main(String[] args) {
		Client client = ClientBuilder.newClient();
		WebTarget target = client.target(RESOURCE_URI);
		Response response = target.request().get();
		String resStr = response.readEntity(String.class);
		System.out.println("***********Server Response**********");
		System.out.println(resStr);
	}

}
