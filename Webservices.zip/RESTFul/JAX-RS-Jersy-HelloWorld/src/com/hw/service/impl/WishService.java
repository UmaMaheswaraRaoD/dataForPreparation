package com.hw.service.impl;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;

@Path("/wish")
public class WishService {

	@Path("/wish/{name}")
	@GET
	public Response wish(@PathParam("name") String name) {
		String result = "<h1>" + name + ", Welcome to RESTful Services</h1>";
		return Response.ok(result).build();
	}

	@Path("/greet/{name}")
	@GET
	public Response greeting(@QueryParam("name") String name) {
		String result = "<h1>" + name + ", Welcome to RESTful Services</h1>";
		return Response.ok(result).build();
	}
}
