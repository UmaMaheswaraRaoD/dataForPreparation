package com.nit.apps;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

public class XMLWriter {

	public static void main(String[] args) {

		String file = "New-Devices.xml";

		List<Device> deviceList = new ArrayList<Device>();
		deviceList.add(new Device("iPhone", "6s"));
		deviceList.add(new Device("iPhone", "7"));
		deviceList.add(new Device("iPad", "2"));

		XMLOutputFactory outputFactory = XMLOutputFactory.newFactory();

		try (FileOutputStream fos = new FileOutputStream(file)) {
			XMLStreamWriter writer = outputFactory.createXMLStreamWriter(fos);

			writer.writeStartDocument();
			writer.writeCharacters("\n");
			writer.writeStartElement("devices");
			writer.writeCharacters("\n");

			for (Device d : deviceList) {
				writer.writeCharacters("\t");
				writer.writeStartElement("device");
				writer.writeCharacters("\n\t\t");
				writer.writeStartElement("name");
				writer.writeCharacters(d.getName());
				writer.writeEndElement();
				writer.writeCharacters("\n\t\t");
				writer.writeStartElement("model");
				writer.writeCharacters(d.getModel());
				writer.writeEndElement();
				writer.writeCharacters("\n\t");
				writer.writeEndElement();
				writer.writeCharacters("\n");
			}
			writer.writeEndElement();
			writer.writeEndDocument();
			writer.close();

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (XMLStreamException e) {
			e.printStackTrace();
		}
	}

}
