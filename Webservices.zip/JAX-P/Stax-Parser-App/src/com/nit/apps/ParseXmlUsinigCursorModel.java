package com.nit.apps;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

public class ParseXmlUsinigCursorModel {
	private static boolean isName = false;
	private static boolean isModel = false;
	static String text = "";

	public static void main(String[] args) {
		String xmlFile = "Devices.xml";
		List<Device> deviceList = parseXML(xmlFile);
		for (Device d : deviceList) {
			System.out.println(d);
		}
	}

	private static List<Device> parseXML(String xmlFile) {
		List<Device> deviceList = null;
		Device dev = null;
		XMLInputFactory factory = XMLInputFactory.newFactory();
		try (FileInputStream fis = new FileInputStream(xmlFile);) {
			XMLStreamReader reader = factory.createXMLStreamReader(fis);

			while (reader.hasNext()) {
				switch (reader.getEventType()) {
				case XMLStreamConstants.START_ELEMENT:
					String elementName = reader.getLocalName();
					switch (elementName) {
					case "devices":
						deviceList = new ArrayList<>();
						break;
					case "device":
						dev = new Device();
						break;
					case "name":
						isName = true;
						break;
					case "model":
						isModel = true;
						break;
					default:
						break;
					}
					break;
				case XMLStreamConstants.CHARACTERS:
					if (isName) {
						dev.setName(reader.getText());
						isName = false;
					} else if (isModel) {
						dev.setModel(reader.getText());
						isModel = false;
					}
					if (reader.hasText())
						text = reader.getText();
					break;
				case XMLStreamConstants.END_ELEMENT:
					elementName = reader.getLocalName();
					if (elementName.equals("device"))
						deviceList.add(dev);
					break;

				case XMLStreamConstants.START_DOCUMENT:
					deviceList = new ArrayList<>();
					break;
				}

				reader.next();
			}
			reader.close();
		} catch (IOException | XMLStreamException e) {
			e.printStackTrace();
		}
		return deviceList;
	}

}
