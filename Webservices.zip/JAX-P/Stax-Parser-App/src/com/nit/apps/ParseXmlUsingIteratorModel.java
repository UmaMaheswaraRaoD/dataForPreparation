package com.nit.apps;

import java.io.FileReader;
import java.util.Iterator;

import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.events.Attribute;
import javax.xml.stream.events.Characters;
import javax.xml.stream.events.StartElement;
import javax.xml.stream.events.XMLEvent;

public class ParseXmlUsingIteratorModel {

	static boolean isName = false;
	static boolean isCeoName = false;
	static boolean isEmail = false;
	static boolean isPhno = false;

	public static void main(String[] args) throws Exception {
		XMLInputFactory factory = XMLInputFactory.newInstance();
		XMLEventReader reader = factory.createXMLEventReader(new FileReader(
				"Company.xml"));

		while (reader.hasNext()) {
			XMLEvent event = reader.nextEvent();

			if (event.isStartDocument()) {
				System.out.println("Document parsing Started...");
			}
			if (event.isStartElement()) {
				StartElement se = (StartElement) event;
				if (se.getName().toString().equals("company")) {
					Iterator<Attribute> itr = se.getAttributes();
					while (itr.hasNext()) {
						Attribute a = itr.next();
						System.out.println(a.getName() + "-->" + a.getValue());
					}
				} else if (se.getName().toString().equals("name")) {
					isName = true;
				} else if (se.getName().toString().equals("ceo-name")) {
					isCeoName = true;
				} else if (se.getName().toString().equals("email")) {
					isEmail = true;
				} else if (se.getName().toString().equals("phone")) {
					isPhno = true;
				}
			}

			if (event.isCharacters()) {
				Characters ch = (Characters) event;
				if (isName) {
					System.out.println("Name : " + ch);
					isName = false;
				} else if (isCeoName) {
					System.out.println("Ceo Name : " + ch);
					isCeoName = false;
				} else if (isEmail) {
					System.out.println("Email : " + ch);
					isEmail = false;
				} else if (isPhno) {
					System.out.println("Phno : " + ch);
					isPhno = false;
				}
			}
		}
	}

}
