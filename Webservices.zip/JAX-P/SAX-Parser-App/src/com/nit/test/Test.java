package com.nit.test;

import java.io.File;
import java.io.FileInputStream;
import java.util.List;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import com.nit.account.Account;
import com.nit.account.AccountHandler;
import com.nit.bookstore.BookHandler;
import com.nit.po.PoHandler;

public class Test {

	public static void main(String[] args) throws Exception {

		System.out.println("===================Po.xml Parsing==================================\n");

		// Reading po.xml file data
		FileInputStream fis1 = new FileInputStream(new File("po.xml"));
		SAXParserFactory factory1 = SAXParserFactory.newInstance();
		SAXParser parser1 = factory1.newSAXParser();
		parser1.parse(fis1, new PoHandler());

		System.out.println("\n=================Account.xml Parsing =================================\n");

		// Reading Account.xml file data and storing in model object
		FileInputStream fis2 = new FileInputStream(new File("Account.xml"));
		SAXParserFactory factory2 = SAXParserFactory.newInstance();
		SAXParser parser2 = factory2.newSAXParser();
		parser2.parse(fis2, new AccountHandler());

		// Getting Account Objects
		List<Account> accounts = new AccountHandler().getData();
		if (!accounts.isEmpty()) {
			for (Account acc : accounts) {
				System.out.println(acc);
			}
		}

		System.out.println("\n=====================BookStore.xml parsing =============================\n");

		// Reading BookStore.xml file data and storing in model object
		FileInputStream fis3 = new FileInputStream(new File("BookStore.xml"));
		SAXParserFactory factory3 = SAXParserFactory.newInstance();
		SAXParser parser3 = factory3.newSAXParser();
		parser3.parse(fis3, new BookHandler());

	}
}
