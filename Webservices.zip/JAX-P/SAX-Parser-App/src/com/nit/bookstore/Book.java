package com.nit.bookstore;

/**
 * This class is used to store Book Info
 * 
 * @author Ashok
 *
 */
public class Book {

	private Integer bookId;
	private String bookIsbn;
	private String bookTitle;
	private Double price;

	public Integer getBookId() {
		return bookId;
	}

	public void setBookId(Integer bookId) {
		this.bookId = bookId;
	}

	public String getBookIsbn() {
		return bookIsbn;
	}

	public void setBookIsbn(String bookIsbn) {
		this.bookIsbn = bookIsbn;
	}

	public String getBookTitle() {
		return bookTitle;
	}

	public void setBookTitle(String bookTitle) {
		this.bookTitle = bookTitle;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "Book [bookId=" + bookId + ", bookIsbn=" + bookIsbn + ", bookTitle=" + bookTitle + ", price=" + price
				+ "]";
	}

}
