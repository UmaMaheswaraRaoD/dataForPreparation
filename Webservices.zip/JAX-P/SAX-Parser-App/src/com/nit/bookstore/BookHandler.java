package com.nit.bookstore;

import java.util.ArrayList;
import java.util.List;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class BookHandler extends DefaultHandler {

	boolean book, id, isbn, title, price;

	private List<Book> booksList = null;
	private Book b = null;
	private String content = null;

	@Override
	public void startDocument() throws SAXException {
		booksList = new ArrayList<Book>();
	}

	@Override
	public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
		if (qName.equals("book")) {
			b = new Book();
			b.setBookId(Integer.parseInt(attributes.getValue("id")));
		}

	}

	@Override
	public void characters(char[] ch, int start, int length) throws SAXException {
		content = new String(ch, start, length);
	}

	@Override
	public void endElement(String uri, String localName, String qName) throws SAXException {
		switch (qName) {
		case "isbn":
			b.setBookIsbn(content);
			break;
		case "title":
			b.setBookTitle(content);
			break;
		case "price":
			b.setPrice(Double.parseDouble(content));
			break;
		case "book":
			booksList.add(b);
			break;
		}
	}

	@Override
	public void endDocument() throws SAXException {
		if (!booksList.isEmpty()) {
			for (Book b : booksList) {
				System.out.println(b);
			}
		}
	}

}
