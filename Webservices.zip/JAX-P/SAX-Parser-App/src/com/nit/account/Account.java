package com.nit.account;

public class Account {

	private Integer accId;
	private String holderName;
	private String type;
	private Double amount;

	public Integer getAccId() {
		return accId;
	}

	public void setAccId(Integer accId) {
		this.accId = accId;
	}

	public String getHolderName() {
		return holderName;
	}

	public void setHolderName(String holderName) {
		this.holderName = holderName;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	@Override
	public String toString() {
		return "Account [accId=" + accId + ", holderName=" + holderName + ", type=" + type + ", amount=" + amount + "]";
	}

}
