package com.nit.account;

import java.util.ArrayList;
import java.util.List;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class AccountHandler extends DefaultHandler {

	private boolean type;
	private boolean id;
	private boolean name;
	private boolean amt;
	private Account ac = null;
	private static List<Account> accounts = new ArrayList<>();

	@Override
	public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
		if (qName.equals("Account")) {
			ac = new Account();
			ac.setType(attributes.getValue("type"));
		} else if (qName.equals("Id")) {
			id = true;
		} else if (qName.equals("Amt")) {
			amt = true;
		} else if (qName.equals("Name")) {
			name = true;
		}

	}

	@Override
	public void endElement(String uri, String localName, String qName) throws SAXException {
		if (qName.equals("Account")) {
			accounts.add(ac);
		}
	}

	@Override
	public void characters(char[] ch, int start, int length) throws SAXException {
		if (id) {
			ac.setAccId(Integer.parseInt(new String(ch, start, length)));
			id = false;
		} else if (name) {
			ac.setHolderName(new String(ch, start, length));
			name = false;
		} else if (amt) {
			ac.setAmount(Double.parseDouble(new String(ch, start, length)));
			amt = false;
		}
	}

	public List<Account> getData() {
		return accounts;
	}

}
