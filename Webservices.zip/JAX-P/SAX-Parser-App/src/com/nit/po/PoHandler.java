package com.nit.po;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class PoHandler extends DefaultHandler {

	boolean itemCode, quanity, addrLine1, city, state, zip, country;

	@Override
	public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
		if (qName.equals("itemCode")) {
			itemCode = true;
		} else if (qName.equals("quantity")) {
			quanity = true;
		} else if (qName.equals("addrLine1")) {
			addrLine1 = true;
		} else if (qName.equals("city")) {
			city = true;
		} else if (qName.equals("state")) {
			state = true;
		} else if (qName.equals("zip")) {
			zip = true;
		} else if (qName.equals("country")) {
			country = true;
		}
	}

	@Override
	public void characters(char[] ch, int start, int length) throws SAXException {
		if (itemCode) {
			System.out.println("ItemCode : " + new String(ch, start, length));
			itemCode = false;
		}

		if (quanity) {
			System.out.println("Quanity : " + new String(ch, start, length));
			quanity = false;
		}
		if (addrLine1) {
			System.out.println("AddrLine1 : " + new String(ch, start, length));
			addrLine1 = false;
		}
		if (city) {
			System.out.println("City : " + new String(ch, start, length));
			city = false;
		}
		if (state) {
			System.out.println("State : " + new String(ch, start, length));
			state = false;
		}
		if (zip) {
			System.out.println("Zip : " + new String(ch, start, length));
			zip = false;
		}
		if (country) {
			System.out.println("Country : " + new String(ch, start, length));
			country = false;
		}

	}

	@Override
	public void startDocument() throws SAXException {
		System.out.println("start document....po.xml");
	}

	@Override
	public void endDocument() throws SAXException {
		System.out.println("end document....po.xml");
	}

}
