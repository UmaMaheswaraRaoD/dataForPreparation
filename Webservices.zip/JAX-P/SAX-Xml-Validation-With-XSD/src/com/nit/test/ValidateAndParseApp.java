package com.nit.test;

import java.io.File;
import java.io.FileInputStream;

import javax.xml.XMLConstants;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;

import com.nit.bookstore.BookHandler;

public class ValidateAndParseApp {

	public static void main(String[] args) throws Exception {

		// Validate xml against xsd
		boolean status = validateXmlAgainstXsd("BookStore.xsd", "BookStore.xml");

		// If xml is valid - then parse it
		if (status) {
			SAXParserFactory factory = SAXParserFactory.newInstance();
			factory.setValidating(true);
			SAXParser parser = factory.newSAXParser();

			// Reading BookStore.xml file data and storing in model object
			FileInputStream fis = new FileInputStream(new File("BookStore.xml"));
			parser.parse(fis, new BookHandler());
		} else {
			// If xml is not valid - don't parse it
			System.out.println("BookStore.xml is not valid as per BookStore.xsd");
		}

	}

	public static boolean validateXmlAgainstXsd(String xsdPath, String xmlPath) {
		try {
			SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
			Schema schema = schemaFactory.newSchema(new File(xsdPath));
			Validator validator = schema.newValidator();
			validator.validate(new StreamSource(xmlPath));
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}

		return true;
	}

}
