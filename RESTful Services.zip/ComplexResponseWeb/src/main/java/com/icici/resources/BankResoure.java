package com.icici.resources;

import java.net.URI;
import java.net.URISyntaxException;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.NewCookie;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;
import javax.ws.rs.core.Response.Status;

import com.icici.domain.PersonInfo;

@Path("/bank")
public class BankResoure {

	@Path("/getBalance/{accno}")
	@GET
	@Consumes(MediaType.TEXT_PLAIN)
	@Produces(MediaType.TEXT_PLAIN)
	public Response getBalance(@PathParam("accno") String accNo) {
		Response resp = null;
		ResponseBuilder builder = null;
		builder = Response.ok("The Balance of Acc No : " + accNo
				+ " is 10000.00");
		resp = builder.build();
		return resp;
	}

	@Path("/reqCheckBook")
	@POST
	@Consumes(MediaType.TEXT_PLAIN)
	@Produces(MediaType.TEXT_PLAIN)
	public Response reqForCheckBook(String accNo) {
		System.out.println("Acc No : " + accNo);
		Response resp = null;
		ResponseBuilder builder = null;
		builder = Response.status(Status.NO_CONTENT);
		resp = builder.build();
		return resp;
	}

	@POST
	@Path("/applyCreditCard")
	@Consumes(MediaType.APPLICATION_XML)
	public Response applyCreditCard(PersonInfo pinfo) throws URISyntaxException {
		Response response = null;
		/*ResponseBuilder builder = Response.ok();
		builder.header("Req-Num", "P101");
		return response;*/
		NewCookie cookie = null;

		cookie = new NewCookie("interaction-id", "2424");
		return Response.created(new URI("/rest/bank/applyCredit_Step2"))
				.cookie(cookie).build();
	}
}
