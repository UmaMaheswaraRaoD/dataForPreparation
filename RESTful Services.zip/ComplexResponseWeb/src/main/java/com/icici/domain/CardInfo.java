package com.icici.domain;

public class CardInfo {

}
