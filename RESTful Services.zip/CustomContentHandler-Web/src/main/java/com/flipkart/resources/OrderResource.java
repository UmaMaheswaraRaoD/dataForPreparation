package com.flipkart.resources;

import java.util.UUID;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.flipkart.domain.Order;

@Path("/order")
public class OrderResource {

	@POST
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/placeOrder")
	public String placeOrder(Order order) {
		order.setOrderId(UUID.randomUUID().toString());
		order.setOrderStatus("In-Progress");
		String msg = "Your order for item code : " + order.getItemCode()
				+ " Is accepted and under processing \n";
		msg = msg + " Track your Order using Order Id : " + order.getOrderId();
		return msg;
	}

	@GET
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Path("/getOrderInfo/{orderId}")
	public Order getOrderInfo(@PathParam("orderId") String orderId) {
		System.out.println("Order Id : " + orderId);
		Order order = new Order();
		order.setOrderId(orderId);
		order.setItemCode("IC1001");
		order.setOrderStatus("In-Progress");
		return order;
	}
}
