package com.rest.resource.clients;

import org.jboss.resteasy.client.ClientRequest;
import org.jboss.resteasy.client.ClientResponse;

public class GreetResourceClient {

	private static final String RESOURCE_URI = "http://localhost:6060/RestEasy-BootStrapping/api/greet";

	public static void main(String[] args) throws Exception {
		ClientRequest req = new ClientRequest(RESOURCE_URI);
		
		ClientResponse<String> response = req.get(String.class);
		
		System.out.println("*******Resource Response**********");
		
		String respStr = response.getEntity();
		System.out.println(respStr);
	}

}
